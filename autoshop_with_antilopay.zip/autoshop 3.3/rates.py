import aiohttp
import os
import ssl
import socket
import certifi
from loguru import logger as log


_SSL = ssl.create_default_context(cafile=certifi.where())


async def get_exchanges(amount: float, cur1: str, cur2: str) -> float:
    if amount == 0.0 or amount == 0:
        return 0.0

    timeout_total = int(os.getenv("RATES_TIMEOUT", "30"))
    family = socket.AF_INET if os.getenv("RATES_FORCE_IPV4", "").strip().lower() in {"1", "true", "yes"} else 0

    connector_kwargs = {"ssl": _SSL}
    if family:
        connector_kwargs["family"] = family

    try:
        connector = aiohttp.TCPConnector(**connector_kwargs)
        async with aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=timeout_total),
            connector=connector,
            trust_env=True,
        ) as session:
            async with session.get(f"https://api.exchangerate-api.com/v4/latest/{cur1}") as resp:
                res = await resp.json(content_type=None)
                rate = res["rates"][cur2]
                return float(rate)
    except Exception as e:
        log.warning("Rates request failed ({}->{}): {}", cur1, cur2, e)
        return 0.0


async def get_def_exchanges():
    rate_usd_to_rub = float(await get_exchanges(1, "USD", "RUB"))
    rate_usd_to_eur = float(await get_exchanges(1, "USD", "EUR"))
    rate_eur_to_rub = float(await get_exchanges(1, "EUR", "RUB"))
    rate_eur_to_usd = float(await get_exchanges(1, "EUR", "USD"))
    rate_rub_to_usd = float(await get_exchanges(1, "RUB", "USD"))
    rate_rub_to_eur = float(await get_exchanges(1, "RUB", "EUR"))

    return (
        rate_usd_to_rub,
        rate_usd_to_eur,
        rate_eur_to_rub,
        rate_eur_to_usd,
        rate_rub_to_usd,
        rate_rub_to_eur,
    )
