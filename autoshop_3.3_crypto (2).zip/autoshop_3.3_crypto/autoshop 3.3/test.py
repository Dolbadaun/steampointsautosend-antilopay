from tgbot.services.db import DB
import asyncio

async def main():
    db = await DB()
    shops = await db.get_shop_admins_and_admins(8)
    print(shops)

if __name__ == "__main__":
    asyncio.run(main())