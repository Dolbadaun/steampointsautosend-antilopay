# -*- coding: utf-8 -*-
"""
tgbot/handlers/_antidup_helpers.py
Идемпотентность заказов + универсальный user_id.
"""
import os
import time
from asyncio import Lock

ORDER_GUARD_TTL = int(os.getenv("ORDER_GUARD_TTL", "120"))

_ORDER_GUARD_TS: dict = {}
_ORDER_GUARD_LOCKS: dict = {}

def _normalize_link_for_key(link: str) -> str:
    link = (link or "").strip().lower()
    if link.endswith('/'):
        link = link[:-1]
    return link

def _order_key(user_id: int, steam_link: str, amount: int) -> str:
    return f"{user_id}|{_normalize_link_for_key(steam_link)}|{int(amount)}"

async def _guard_try_enter(key: str) -> bool:
    lock = _ORDER_GUARD_LOCKS.setdefault(key, Lock())
    async with lock:
        now = time.time()
        ts = _ORDER_GUARD_TS.get(key)
        if ts and (now - ts) < ORDER_GUARD_TTL:
            return False
        _ORDER_GUARD_TS[key] = now
        return True

def _resolve_user_id_from_locals(_locals: dict) -> int:
    for key in ("message", "msg", "call"):
        obj = _locals.get(key)
        if obj is not None:
            fu = getattr(obj, "from_user", None)
            if fu and getattr(fu, "id", None):
                return fu.id
    m = _locals.get("message") or _locals.get("msg")
    if m is not None:
        ch = getattr(m, "chat", None)
        if ch and getattr(ch, "id", None):
            return ch.id
    return 0

__all__ = [
    "ORDER_GUARD_TTL",
    "_order_key",
    "_guard_try_enter",
    "_resolve_user_id_from_locals",
]
