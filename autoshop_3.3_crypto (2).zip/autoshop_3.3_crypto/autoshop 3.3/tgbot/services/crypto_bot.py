import aiohttp
import asyncio
import os
import ssl
import socket
import certifi
from loguru import logger as log


class CryptoBot:
    def __init__(self, api_token: str):
        self.token = api_token.strip() if api_token else ""
        self.base_url = "https://pay.crypt.bot/api"

        total = int(os.getenv("CRYPTOBOT_TIMEOUT", "120"))
        self.timeout = aiohttp.ClientTimeout(total=total)

        # Windows/aiohttp can miss system CA chain -> use certifi bundle
        self.ssl_context = ssl.create_default_context(cafile=certifi.where())

        # Optional: force IPv4
        family = socket.AF_INET if os.getenv("CRYPTOBOT_FORCE_IPV4", "").strip().lower() in {"1", "true", "yes"} else 0
        self._connector_kwargs = {"ssl": self.ssl_context}
        if family:
            self._connector_kwargs["family"] = family

        loop = asyncio.get_event_loop()
        loop.create_task(self.check())

    def _headers(self) -> dict:
        return {"Crypto-Pay-API-Token": self.token}

    async def _request(self, method: str, api_method: str, *, params=None, data=None, json_body=None):
        url = f"{self.base_url}/{api_method}"
        proxy = os.getenv("CRYPTOBOT_HTTP_PROXY") or os.getenv("CRYPTOBOT_PROXY")
        connector = aiohttp.TCPConnector(**self._connector_kwargs)
        async with aiohttp.ClientSession(
            headers=self._headers(),
            timeout=self.timeout,
            connector=connector,
            trust_env=True,
        ) as session:
            async with session.request(method, url, params=params, data=data, json=json_body, proxy=proxy) as resp:
                return await resp.json(content_type=None)

    async def get_me(self):
        return await self._request("GET", "getMe")

    async def get_balance(self):
        return await self._request("GET", "getBalance")

    async def check(self):
        # do not crash the bot on startup
        try:
            result = await self.get_me()
        except Exception as e:
            log.error("CryptoBot getMe failed: {}", e)
            return
        if not isinstance(result, dict) or not result.get("ok"):
            log.error("CryptoBot token/network error: {}", result)
            return

    async def create_bill(self, amount, asset):
        rates = await self._request("GET", "getExchangeRates")
        if not isinstance(rates, dict) or not rates.get("ok"):
            return rates

        rate_value = None
        for item in rates.get("result", []):
            if item.get("source") == asset and item.get("target") == "RUB":
                rate_value = item.get("rate")
                break
        if rate_value is None:
            return {"ok": False, "error": "RATE_NOT_FOUND", "description": f"Rate {asset}->RUB not found"}

        try:
            amount_crypto = float(amount) / float(rate_value)
            amount_crypto = round(amount_crypto, 6)
        except Exception as e:
            return {"ok": False, "error": "BAD_AMOUNT", "description": str(e)}

        # IMPORTANT: method name is case-sensitive: createInvoice
        data = {"amount": str(amount_crypto), "asset": asset}
        return await self._request("POST", "createInvoice", data=data)

    async def check_bill(self, bill_id):
        r = await self._request("GET", "getInvoices", params={"invoice_ids": str(bill_id), "count": 1})
        try:
            if r.get("ok") and r["result"]["items"] and r["result"]["items"][0]["status"] == "paid":
                return True
        except Exception:
            pass
        return False
