from aiogram import Dispatcher, Bot
import asyncio
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher import FSMContext
from aiogram.types import Message, CallbackQuery, Update
from traceback import print_exc
import math
from tgbot.utils.utils_functions import get_admins
from aiogram.dispatcher.middlewares import BaseMiddleware
from loguru import logger
from aiogram.dispatcher.handler import CancelHandler, current_handler
from aiogram.utils.exceptions import Throttled, MessageNotModified, ChatNotFound, Unauthorized, MessageCantBeDeleted
import nest_asyncio
import os
import random
from aiogram.types import Message, CallbackQuery
import time
from datetime import datetime, timedelta
from tgbot.keyboards.inline_user import sub, user_menu, back_to_profile, profile_inl, \
    chat_inl, news_inl, faq_inl, support_inll, contest_inl, choose_contest, choose_languages_kb, nal_products_shops, \
    back_to_user_menu, open_products, open_positions, open_pod_cat_positions, pos_buy_inl, choose_buy_items, open_shops, \
    refill_inl, refill_open_inl, choose_asset_crypto, refill_open_inl_shaxta, back_refill, get_extra_refill_kb
from tgbot.keyboards.inline_admin import admin_menu, pos_admin_menu, custom_btn, shop_admin_menu, \
    confirm_extra_refill_bots
from tgbot.data.config import db, currencies, lang_ru, lang_ru, lang_en
from tgbot.data.loader import bot
from tgbot.utils.other_functions import open_profile, convert_ref
from contextlib import suppress
from tgbot.filters.filters import IsAdmin, IsBuy, IsBan, IsSub, IsRefill, IsWork, IsContestOn, IsPosAdmin, IsShopAdmin
from tgbot.utils.utils_functions import convert_words, get_channels, end_contest, \
    split_messages, get_date, get_unix, send_admins, get_exchange, update_balance, \
    get_language
from tgbot.states.users import UsersCoupons, UserProducts, UserRefills
from tgbot.data import config
from tgbot.handlers.users_refills import payok, aaio, crystal, lzt, qiwi, shaxta, lava, yoo, crypto, shaxta, greengo

extra_payment_text = """
<b>💳 Карта: <code>{card}</code>
💰 Сумма: <code>{sum} RUB</code>

❗ Переводите точную сумму, в ином случае депозит не будет зачислен!
❗ Оплата проверяется вручную администрацией в течение часа!
❗ Ночью могут быть задержки до утра.Просьба не писать об этом в тех.поддержку,мы сами утром проверим все заявки на пополнение</b>
    """

nest_asyncio.apply()

class ExistsUserMiddleware(BaseMiddleware):

    def __init__(self):
        super(ExistsUserMiddleware, self).__init__()

    async def on_process_update(self, update: Update, data: dict):
        user = update
        if "message" in update:
            user = update.message.from_user
            logger.info(f"{user.full_name} - {update.message.text}")
        elif "callback_query" in update:
            user = update.callback_query.from_user
            logger.info(f"{user.full_name} - {update.callback_query.data} (Callback)")
        try:
            if user is not None:
                if not user.is_bot:
                    self.id = user.id
                    self.user_name = user.username
                    self.full_name = user.full_name
                    self.bot = await update.bot.get_me()
                    self.settings = await db.get_settings()
                    if self.user_name is None:
                        self.user_name = ""
                    if await db.get_user(id=self.id) is None:
                        await db.register_user(id=self.id, user_name=self.user_name, first_name=self.full_name)
                    else:
                        self.user = await db.get_user(id=self.id)
                        if self.user['user_name'] != self.user_name:
                            await db.update_user(self.id, user_name=self.user_name)
                        if self.user['full_name'] != self.full_name:
                            await db.update_user(self.id, first_name=self.full_name)

                        if len(self.user_name) >= 1:
                            if self.user_name != self.user['user_name']:
                                await db.update_user(self.id, user_name=self.user_name)
                        else:
                            await db.update_user(self.id, user_name="")
        except:
            pass


class ThrottlingMiddleware(BaseMiddleware):
    def __init__(self, limit=0.5, key_prefix='antiflood_'):
        self.rate_limit = limit
        self.prefix = key_prefix
        super(ThrottlingMiddleware, self).__init__()

    async def on_process_message(self, message: Message, data: dict):
        handler = current_handler.get()
        dispatcher = Dispatcher.get_current()

        if handler:
            limit = getattr(handler, "throttling_rate_limit", self.rate_limit)
            key = getattr(handler, "throttling_key", f"{self.prefix}_{handler.__name__}")
        else:
            limit = self.rate_limit
            key = f"{self.prefix}_message"

        if message.from_user.id not in get_admins():
            try:
                await dispatcher.throttle(key, rate=limit)
            except Throttled as t:
                await self.message_throttled(message, t)
                raise CancelHandler()

    @staticmethod
    async def message_throttled(message: Message, throttled: Throttled):
        if throttled.exceeded_count <= 2:
            await message.reply("<b>❗ Пожалуйста, не спамьте.</b>")


# Изменение лимитов отправки сообщения у декораторов
def rate_limit(limit: int, key=None):
    def decorator(func):
        setattr(func, "throttling_rate_limit", limit)
        if key:
            setattr(func, "throttling_key", key)
        return func

    return decorator


def setup_middlewares(dp: Dispatcher):
    dp.middleware.setup(ExistsUserMiddleware())
    dp.middleware.setup(ThrottlingMiddleware())

def handlers(dp: Dispatcher):
    @dp.callback_query_handler(text="extra_refill", state="*")
    async def extra_refill_callback(call: CallbackQuery, state: FSMContext):
        await state.finish()
        payment = await db.get_extra_payments()
        if bool(payment['is_on']):
            await UserRefills.here_amount_extra.set()
            payment = await db.get_extra_payments()
            await call.message.delete()
            way_refill_text = "<b>💥 Способ: <code>{way}</code> \n💰 Введите сумму пополнения:</b>"
            texts = await get_language(call.from_user.id)
            await call.message.answer(
                way_refill_text.format(way=payment['name']),
                reply_markup=back_refill(texts))

    @dp.callback_query_handler(text_startswith="extra_refill_check:", state="*")
    async def extra_refill_check_callback(call: CallbackQuery, state: FSMContext):
        try:
            await state.finish()
            payment = await db.get_extra_payments()
            if bool(payment['is_on']):
                amount = float(call.data.split(":")[1])
                rand_num = float(call.data.split(":")[2])
                text = f"""<b>Новое пополнение через карту:
Пользователь: {call.from_user.get_mention()} | <code>{call.from_user.id}</code> | @{call.from_user.username}
Сумма: <code>{amount} RUB ({amount - rand_num} RUB)</code></b>"""
                # don't touch bot
                await bot.send_message(config.refills_channel, text=text,
                                       reply_markup=await confirm_extra_refill_bots(call.from_user.id, amount,
                                                                                    rand_num, call.bot.id))
                await call.message.edit_text(
                    f"<b>✅ Пополнение на <code>{amount - rand_num} RUB</code> отправлено на проверку.</b>")
        except:
            print_exc()

    @dp.message_handler(state=UserRefills.here_amount_extra)
    async def here_amount_extra(msg: Message, state: FSMContext):
        payment = await db.get_extra_payments()
        if bool(payment['is_on']):
            if msg.text.isdigit() or msg.text.replace(".", "").isdigit() or msg.text.replace(",", "").isdigit():
                pay_amount = float(msg.text.replace(",", "."))
                rand_num = random.randint(100, 200)
                pay_amount += rand_num
                payment = await db.get_extra_payments()
                if pay_amount - rand_num >= float(payment['min_sum']):
                    await state.finish()
                    text = extra_payment_text.format(card=payment['text'], sum=pay_amount)
                    await msg.answer(text, reply_markup=get_extra_refill_kb(pay_amount, rand_num))
                else:
                    await msg.reply(
                        f"<b>❗ Минимальная сумма пополнения: <code>{payment['min_sum']} RUB</code>, попробуйте еще раз:</b>")
            else:
                await msg.reply("<b>❗ Сумма должна быть числом, попробуйте еще раз:</b>")

    @dp.callback_query_handler(text="crypto_bot", state="*")
    async def cryt(call: CallbackQuery, state: FSMContext):
        await state.finish()
        await call.message.delete()
        texts = await get_language(call.from_user.id)
        await call.message.answer(texts.choose_crypto, reply_markup=choose_asset_crypto())

    async def success_refill(call: CallbackQuery, way, amount, id, user_id, pay_amount):
        try:
            texts = await get_language(user_id)

            user = await db.get_user(id=user_id)
            curr = (await db.get_settings())['currency']
            amount_rub, amount_euro, amount_dollar, ref_percent, ref_amount, main_amount = 0, 0, 0, 0, 0, 0

            pay_amount = float(pay_amount)

            await db.add_refill(amount, way, user_id, user['user_name'], user['first_name'], comment=id)

            amount_rub = float(amount)
            amount_euro = await get_exchange(amount_rub, 'RUB', 'EUR')
            amount_dollar = await get_exchange(amount_rub, 'RUB', 'USD')

            if curr == "rub":
                pay_rub = user['balance_rub'] + pay_amount
                pay_dollar = user['balance_dollar'] + await get_exchange(pay_amount, 'RUB', 'USD')
                pay_euro = user['balance_euro'] + await get_exchange(pay_amount, 'RUB', 'EUR')
            elif curr == "usd":
                pay_dollar = user['balance_dollar'] + pay_amount
                pay_rub = user['balance_rub'] + await get_exchange(pay_amount, 'USD', 'RUB')
                pay_euro = user['balance_euro'] + await get_exchange(pay_amount, 'USD', 'EUR')
            elif curr == "euro":
                pay_euro = user['balance_euro'] + pay_amount
                pay_rub = user['balance_rub'] + await get_exchange(pay_amount, 'EUR', 'RUB')
                pay_dollar = user['balance_dollar'] + await get_exchange(pay_amount, 'EUR', 'USD')

            msg = f"💰 Произошло пополнение баланса! \n" \
                  f"👤 Пользователь: <b>@{user['user_name']}</b> | <a href='tg://user?id={user['id']}'>{user['first_name']}</a> | <code>{user['id']}</code>\n" \
                  f"💵 Сумма пополнения: <code>{pay_amount}{config.currencies[curr]['sign']}</code>\n" \
                  f"🧾 Чек: <code>{id}</code> \n" \
                  f"🤖 Бот: @{(await call.bot.get_me()).username} [<code>{call.bot.id}</code>]" \
                  f"⚙️ Способ: <code>{way}</code>"

            await send_admins(msg, True)
            await db.update_user(id=user_id, total_refill=int(user['total_refill']) + float(amount_rub),
                                 count_refills=int(user['count_refills']) + 1)

            await db.update_user(user_id, balance_rub=pay_rub, balance_dollar=pay_dollar, balance_euro=pay_euro)
            await call.message.delete()
            if way == "shaxtaCard":
                way = texts.shaxta24_card
            await call.message.answer(texts.refill_success_text(way, pay_amount, id, config.currencies[curr]['sign']))

            s = await db.get_settings()
            if s['is_ref'] == "False":
                pass
            elif s['is_ref'] == "True":
                if user['ref_id'] is None:
                    pass
                else:
                    reffer = await db.get_user(id=user['ref_id'])

                    if reffer['ref_lvl'] == 1:
                        ref_percent = s['ref_percent_1']
                    elif reffer['ref_lvl'] == 2:
                        ref_percent = s['ref_percent_2']
                    elif reffer['ref_lvl'] == 3:
                        ref_percent = s['ref_percent_3']

                    ref_amount_rub = int(amount_rub) / 100 * int(ref_percent)
                    ref_amount_euro = int(amount_euro) / 100 * int(ref_percent)
                    ref_amount_dollar = int(amount_dollar) / 100 * int(ref_percent)

                    if curr == 'rub':
                        ref_amount = ref_amount_rub
                    elif curr == 'eur':
                        ref_amount = ref_amount_euro
                    elif curr == 'usd':
                        ref_amount = ref_amount_dollar

                    reffer_id = user['ref_id']
                    reffer = await db.get_user(id=reffer_id)

                    ref_earn_rub = reffer['ref_earn_rub']
                    ref_earn_euro = reffer['ref_earn_euro']
                    ref_earn_dollar = reffer['ref_earn_dollar']

                    add_balance_rub = round(reffer['balance_rub'] + round(ref_amount_rub, 1), 2)
                    add_balance_euro = round(reffer['balance_euro'] + round(ref_amount_euro, 1), 2)
                    add_balance_dollar = round(reffer['balance_dollar'] + round(ref_amount_dollar, 1), 2)

                    name = f"<a href='tg://user?id={user['id']}'>{user['user_name']}</a>"

                    await db.update_user(reffer_id, balance_rub=add_balance_rub, balance_euro=add_balance_euro,
                                         balance_dollar=add_balance_dollar,
                                         ref_earn_rub=ref_earn_rub + round(ref_amount_rub, 1),
                                         ref_earn_dollar=ref_earn_dollar + round(ref_amount_dollar, 1),
                                         ref_earn_euro=ref_earn_euro + round(ref_amount_euro, 1), )

                    await call.bot.send_message(reffer_id,
                                           texts.yes_refill_ref.format(name=name, amount=amount,
                                                                       ref_amount=round(ref_amount, 1),
                                                                       cur=config.currencies[curr]['sign']))
        except:
            print_exc()

    @dp.callback_query_handler(text="refill", state="*")
    async def refill_open(call: CallbackQuery, state: FSMContext):
        await state.finish()
        texts = await get_language(call.from_user.id)
        await call.message.delete()

        if texts.refill_photo:
            await call.message.answer_photo(photo=texts.refill_photo, caption=texts.refill_text,
                                            reply_markup=await refill_inl(texts))
        else:
            await call.message.answer(texts.refill_text, reply_markup=await refill_inl(texts))

    @dp.callback_query_handler(text_startswith="refill:", state="*")
    async def refill_(call: CallbackQuery, state: FSMContext):
        await state.finish()
        texts = await get_language(call.from_user.id)
        way = call.data.split(":")[1]

        try:
            asset = call.data.split(":")[2]
            await state.update_data(cache_asset=asset)
        except:
            pass

        await state.update_data(here_way=way)
        await UserRefills.here_amount.set()
        curr = (await db.get_settings())['currency']

        min_amount = texts.min_amount
        max_amount = texts.max_amount

        if way == "shaxta":
            min_amount = texts.shaxta_min_amount

        if curr == 'usd':
            min_amount = await get_exchange(min_amount, 'RUB', 'USD')
            max_amount = await get_exchange(max_amount, 'RUB', 'USD')
        elif curr == 'eur':
            min_amount = await get_exchange(min_amount, 'RUB', 'EUR')
            max_amount = await get_exchange(max_amount, 'RUB', 'EUR')
        await call.message.answer(texts.refill_amount_text.format(min_amount=min_amount,
                                                                  curr=config.currencies[curr]['sign'],
                                                                  max_amount=max_amount))

    @dp.message_handler(state=UserRefills.here_amount)
    async def refill_pay(message: Message, state: FSMContext):
        texts = await get_language(message.from_user.id)
        amount = message.text
        async with state.proxy() as data:
            way = data['here_way']
            try:
                asset = data['cache_asset']
            except:
                pass
        bota = await message.bot.get_me()
        bot_name = bota.username
        us = await db.get_user(id=message.from_user.id)
        user_name = us['user_name']
        pay_amount = float(amount)
        curr = (await db.get_settings())['currency']

        min_amount, max_amount = texts.min_amount, texts.max_amount

        if way == "greengo":
            min_amount = 500

        if curr == 'usd':
            pay_amount = await get_exchange(float(amount), 'USD', 'RUB')
        elif curr == 'eur':
            pay_amount = await get_exchange(float(amount), 'EUR', 'RUB')
        percents = await db.get_payments_percents()
        way_for_percents = way
        ways = {"crystal": 'crystalPay', 'lolz': 'lzt', 'crypto_bot': 'cryptoBot'}
        if way in ways:
            way_for_percents = ways[way]
        amount_with_commission = round(((float(pay_amount) / 100) * int(percents[way_for_percents])) + pay_amount, 2)
        amount_with_commission = math.ceil(amount_with_commission)
        if amount.isdigit() or amount.replace(".", "").isdigit():
            if min_amount <= float(pay_amount) <= max_amount:
                await state.finish()
                if way == "crystal":
                    way = "CrystalPay"
                    crys = await crystal.generate_pay_link(amount=amount_with_commission)
                    link = crys['url']
                    id = crys['id']
                elif way == "qiwi":
                    way = "Qiwi"
                    bill_id = get_unix(True)
                    bill = await qiwi.create_bill(amount=amount_with_commission, comment=bill_id)
                    id = bill['billId']
                    link = bill['payUrl']
                elif way == "lolz":
                    way = "Lolz"
                    comment = lzt.get_random_string()
                    link = lzt.get_link(amount=amount_with_commission, comment=comment)
                    id = comment
                elif way == "lava":
                    way = "Lava"
                    invoice = await lava.create_invoice(amount=amount_with_commission,
                                                        comment=f"Пополнение аккаунта {user_name} на сумму {pay_amount}{config.currencies[curr]['sign']} в боте {bot_name}",
                                                        success_url=f"https://t.me/{bot_name}")
                    link = invoice['data']['url']
                    id = invoice['data']['id']
                elif way == "yoomoney":
                    way = "ЮMoney"
                    order = random.randint(1111111, 9999999)
                    form = yoo.create_yoomoney_link(amount=amount_with_commission, comment=order)
                    link = form['link']
                    id = form['comment']
                elif way == "crypto_bot":
                    way = "CryptoBot"

                    bill = await crypto.create_bill(amount=amount_with_commission, asset=asset)
                    if not isinstance(bill, dict) or not bill.get("ok") or "result" not in bill:
                        err = None
                        if isinstance(bill, dict):
                            err = bill.get("description") or bill.get("error")
                        err = err or "unknown error"
                        await message.answer(f"Не удалось создать счёт CryptoBot: {err}\nПроверь токен Crypto Pay и доступность pay.crypt.bot.")
                        await state.finish()
                        return
                    id = bill["result"]["invoice_id"]
                    link = bill["result"]["pay_url"]
                elif way == "payok":
                    way = "PayOK"
                    cur = await db.get_settings()
                    id = get_unix(True)
                    link = await payok.get_link(payment_id=id, summ=amount_with_commission,
                                                currency=cur['currency'].upper())
                elif way == "aaio":
                    cur = await db.get_settings()
                    way = texts.aaio_short_text
                    id = get_unix(True)
                    link = str(await aaio.create_payment(amount_with_commission, id, cur['currency'].upper()))
                elif way == "shaxta":
                    way = "shaxtaCard"
                    order = await shaxta.create_order(amount_with_commission)
                    p_id = order['data']['orderId']
                    amountExc = order['data']['amountExc']
                else:
                    # greengo
                    way = "greengo"
                    bill = await greengo.create_order(amount=amount_with_commission)
                    p_id = bill['items'][0]['order_id']

                if way == "greengo":
                    await message.answer(texts.refill_gen_text_shaxta.format(
                        way=texts.greengo_text, amount=pay_amount, amountc=amount_with_commission,
                        curr=config.currencies[curr]['sign'],
                        card=bill['items'][0]['wallet_payment'], p_id=p_id
                    ), reply_markup=refill_open_inl_shaxta(texts=texts, way=way, amount=pay_amount, p_id=p_id,
                                                           second_amount=message.text,
                                                           amount_with_commission=amount_with_commission))
                    await state.finish()
                elif way == "shaxtaCard":
                    await message.answer(texts.refill_gen_text_shaxta.format(
                        way=texts.shaxta24_card, amount=pay_amount, amountExc=amountExc,
                        curr=config.currencies[curr]['sign'],
                        card=order['data']['paymentData'], p_id=p_id, amountc=pay_amount
                    ), reply_markup=refill_open_inl_shaxta(texts=texts, way=way, amount=pay_amount, p_id=p_id,
                                                           second_amount=message.text,
                                                           amount_with_commission=amount_with_commission
                                                           ))
                    await state.finish()
                else:
                    await message.answer(texts.refill_gen_text(way=way, amount=amount_with_commission, id=id,
                                                               curr=config.currencies[curr]['sign']),
                                         reply_markup=refill_open_inl(texts=texts,
                                                                      way=way,
                                                                      amount=pay_amount,
                                                                      link=link, id=id, second_amount=message.text,
                                                                      amount_with_commission=amount_with_commission))
                    await state.finish()
            else:
                min_amount = texts.min_amount
                max_amount = texts.max_amount

                if way == "greengo":
                    min_amount = 500

                if curr == 'usd':
                    min_amount = await get_exchange(min_amount, 'RUB', 'USD')
                    max_amount = await get_exchange(max_amount, 'RUB', 'USD')
                elif curr == 'eur':
                    min_amount = await get_exchange(min_amount, 'RUB', 'EUR')
                    max_amount = await get_exchange(max_amount, 'RUB', 'EUR')
                await message.answer(texts.min_max_amount.format(min_amount=min_amount,
                                                                 curr=config.currencies[curr]['sign'],
                                                                 max_amount=max_amount))
        else:
            await message.answer(texts.no_int_amount)

    @dp.callback_query_handler(text_startswith="check_opl:", state='*')
    async def check_refill(call: CallbackQuery, state: FSMContext):
        await state.finish()
        data = call.data.split(':')
        amount = data[2]
        way = data[1]
        id = data[3]
        pay_amount1 = data[4]
        amount_with_commission = data[5]
        texts = await get_language(call.from_user.id)
        if way == "CrystalPay":
            status = await crystal.get_pay_status(invoice_id=id)
            refill = await db.get_refill(receipt=id)
            if status and not refill:
                await success_refill(call, way, amount, id, call.from_user.id, pay_amount1)
            else:
                await call.answer(texts.refill_check_no, True)
        elif way == "Qiwi":
            status = await qiwi.check_bill(bill_id=id)
            refill = await db.get_refill(receipt=id)
            if status and not refill:
                await success_refill(call, way, amount, id, call.from_user.id, pay_amount1)
            else:
                await call.answer(texts.refill_check_no, True)
        elif way == "Lava":
            status = await lava.status_invoice(invoice_id=id)
            refill = await db.get_refill(receipt=id)
            if status and not refill:
                await success_refill(call, way, amount, id, call.from_user.id, pay_amount1)
            else:
                await call.answer(texts.refill_check_no, True)
        elif way == "Lolz":
            status = await lzt.check_payment(amount=amount_with_commission, comment=id)
            refill = await db.get_refill(receipt=id)
            if status is True and not refill:
                await success_refill(call, way, amount, id, call.from_user.id, pay_amount1)
            else:
                if status is False:
                    await call.answer(texts.refill_check_no, True)
                else:
                    await call.answer(status, True)
        elif way == "ЮMoney":
            status = yoo.check_yoomoney_payment(comment=id)
            refill = await db.get_refill(receipt=id)
            if status and not refill:
                await success_refill(call, way, amount, id, call.from_user.id, pay_amount1)
            else:
                await call.answer(texts.refill_check_no, True)
        elif way == "CryptoBot":
            status = await crypto.check_bill(bill_id=id)
            refill = await db.get_refill(receipt=id)
            if status and not refill:
                await success_refill(call, way, amount, id, call.from_user.id, pay_amount1)
            else:
                await call.answer(texts.refill_check_no, True)
        elif way == 'PayOK':
            status = await payok.get_pay(order_id=id)
            refill = await db.get_refill(receipt=id)
            if status and not refill:
                await success_refill(call, way, amount, id, call.from_user.id, pay_amount1)
            else:
                await call.answer(texts.refill_check_no, True)
        elif way == texts.aaio_short_text:
            status = await aaio.check_payment(order_id=id)
            refill = await db.get_refill(receipt=id)
            if status and not refill:
                await success_refill(call, way, amount, id, call.from_user.id, pay_amount1)
            else:
                await call.answer(texts.refill_check_no, True)
        elif way == "shaxtaCard":
            status = await shaxta.check_order(order_id=int(id))
            refill = await db.get_refill(receipt=id)
            if status and not refill:
                await success_refill(call, way, amount, id, call.from_user.id, pay_amount1)
            else:
                await call.answer(texts.refill_check_no, True)
        else:
            #  greengo
            status = await greengo.check_payment(order_id=id)
            refill = await db.get_refill(receipt=id)
            if status and not refill:
                await success_refill(call, way, amount, id, call.from_user.id, pay_amount1)
            else:
                await call.answer(texts.refill_check_no, True)

    @dp.callback_query_handler(text="products:open", state="*")
    async def open_products_users(call: CallbackQuery, state: FSMContext):
        await state.finish()
        texts = await get_language(call.from_user.id)
        shops = await db.get_shops()
        if len(shops) < 1:
            await call.message.delete()
            if texts.products_photo:
                await call.message.answer_photo(photo=texts.products_photo, caption=texts.no_cats,
                                                reply_markup=back_to_user_menu(texts))
            else:
                await call.message.answer(texts.no_cats, reply_markup=back_to_user_menu(texts))
        else:
            await call.message.delete()
            if texts.products_photo:
                await call.message.answer_photo(photo=texts.products_photo, caption=texts.available_cats,
                                                reply_markup=open_shops(texts, shops))
            else:
                await call.message.answer(texts.available_cats, reply_markup=open_shops(texts, shops))

    @dp.callback_query_handler(text_startswith="open_shop:", state="*")
    async def _open_products_users(call: CallbackQuery, state: FSMContext):
        await state.finish()
        shop_id = call.data.split(":")[1]
        texts = await get_language(call.from_user.id)
        shop = await db.get_shop(shop_id)
        if len(await db.get_categories(shop_id)) < 1:
            await call.message.delete()
            if shop['photo']:
                await call.message.answer_photo(photo=shop['photo'], caption=texts.no_cats,
                                                reply_markup=custom_btn("products:open"))
            else:
                await call.message.answer(texts.no_cats, reply_markup=custom_btn("products:open"))

        else:
            await call.message.delete()
            text = texts.available_cats
            admins = await db.get_shop_admins_and_admins(shop_id)
            if call.from_user.id in admins:
                show_profit_amount_all, show_profit_amount_day, show_profit_amount_week = 0, 0, 0
                show_profit_count_all, show_profit_count_day, show_profit_count_week = 0, 0, 0
                show_profit_amount_yesterday, show_profit_amount_month = 0, 0
                show_profit_count_yesterday, show_profit_count_month = 0, 0

                get_purchases = await db.get_purchases_by_shop_id(shop_id)
                s = await db.get_settings()
                today = datetime.today()
                yesterday = datetime.today() - timedelta(days=1)
                profit_yesterday = int(datetime(yesterday.year, yesterday.month, yesterday.day, 00, 00, 00).timestamp())
                profit_month = int(datetime(today.year, today.month, 1, 00, 00, 00).timestamp())
                cur = currencies[s['currency']]['sign']
                for purchase in get_purchases:
                    if s['currency'] == 'rub':
                        purchase_price = purchase['price_rub']
                    elif s['currency'] == 'usd':
                        purchase_price = purchase['price_dollar']
                    elif s['currency'] == 'eur':
                        purchase_price = purchase['price_euro']
                    show_profit_amount_all += purchase_price
                    show_profit_count_all += purchase['count']

                    if purchase['unix'] - s['profit_day'] >= 0:
                        show_profit_amount_day += purchase_price
                        show_profit_count_day += purchase['count']
                    if purchase['unix'] - s['profit_week'] >= 0:
                        show_profit_amount_week += purchase_price
                        show_profit_count_week += purchase['count']
                    if purchase['unix'] - profit_yesterday >= 0 and purchase['unix'] < s['profit_day']:
                        show_profit_amount_yesterday += purchase_price
                        show_profit_count_yesterday += purchase['count']
                    if purchase['unix'] - profit_month >= 0:
                        show_profit_amount_month += purchase_price
                        show_profit_count_month += purchase['count']
                shop_admins = await db.get_shop_admins(shop_id)
                text += f"""
\n<b>💸 Продажи:</b>

💸 За День: <code>{show_profit_count_day}шт</code> (<code>{round(show_profit_amount_day, 2)}{cur}</code>)
💸 За Вчера: <code>{show_profit_count_yesterday}шт</code> (<code>{round(show_profit_amount_yesterday, 2)}{cur}</code>)
💸 За Неделю: <code>{show_profit_count_week}шт</code> (<code>{round(show_profit_amount_week, 2)}{cur}</code>)
💸 За Месяц: <code>{show_profit_count_month}шт</code> (<code>{round(show_profit_amount_month, 2)}{cur}</code>)
💸 За Всё время: <code>{show_profit_count_all}шт</code> (<code>{round(show_profit_amount_all, 2)}{cur}</code>)

<b>⚙️ Админы: </b>

⚙️ Всего админов: <code>{len(shop_admins)} чел</code>
⚙️ Админы:
"""
                for admin in shop_admins:
                    user = await db.get_user(id=admin)
                    text += f"@{user['user_name']}\n "
            if shop['photo']:
                await call.message.answer_photo(photo=shop['photo'], caption=text,
                                                reply_markup=await open_products(texts, shop_id))
            else:
                await call.message.answer(text, reply_markup=await open_products(texts, shop_id))

    @dp.callback_query_handler(text_startswith="mail_cat_open:", state='*')
    async def mail_cat_open(call: CallbackQuery, state: FSMContext):
        texts = await get_language(call.from_user.id)
        await state.finish()
        cat_id = call.data.split(":")[1]

        if len(await db.get_positions(cat_id)) < 1:
            await call.message.answer(texts.no_products, reply_markup=back_to_user_menu(texts))
        else:
            cat = await db.get_category(cat_id)
            await call.message.answer(texts.current_cat.format(name=cat['name']),
                                      reply_markup=await open_positions(texts, cat_id))

    @dp.callback_query_handler(text_startswith="mail_pod_cat_open:", state='*')
    async def mail_pod_cat_open(call: CallbackQuery, state: FSMContext):
        await state.finish()
        texts = await get_language(call.from_user.id)
        pod_cat_id = call.data.split(":")[1]

        if len(await db.get_positions(pod_cat_id=pod_cat_id)) < 1:
            await call.message.answer(texts.no_products)
        else:
            pod_cat = await db.get_pod_category(pod_cat_id)
            await call.message.answer(texts.current_pod_cat.format(name=pod_cat['name']),
                                      reply_markup=await open_pod_cat_positions(texts, pod_cat_id))

    @dp.callback_query_handler(text_startswith="mail_pos_open:", state="*")
    async def mail_pos_open(call: CallbackQuery, state: FSMContext):
        await state.finish()
        texts = await get_language(call.from_user.id)
        pos_id = call.data.split(":")[1]
        pos = await db.get_position(pos_id)
        cat_id = pos['category_id']
        cat = await db.get_category(cat_id)
        items = f"{len(await db.get_items(position_id=pos_id))}шт."
        if pos['infinity'] == "+":
            items = "Безлимит"
        settings = await db.get_settings()
        if settings['currency'] == 'rub':
            price = pos['price_rub']
        elif settings['currency'] == 'usd':
            price = pos['price_dollar']
        elif settings['currency'] == 'eur':
            price = pos['price_euro']
        msg = texts.open_pos_text.format(cat_name=cat['name'], pos_name=pos['name'], price=price,
                                         cur=currencies[settings['currency']]['sign'], items=items,
                                         desc=pos['description'])

        if pos['photo'] is None or pos['photo'] == "-":
            await call.message.answer(msg, reply_markup=await pos_buy_inl(texts, pos_id))
        else:
            await call.bot.send_photo(chat_id=call.from_user.id, photo=pos['photo'], caption=msg,
                                 reply_markup=await pos_buy_inl(texts, pos_id))

    @dp.callback_query_handler(text_startswith="open_category:", state="*")
    async def open_cat_for_buy(call: CallbackQuery, state: FSMContext):
        await state.finish()
        cat_id = call.data.split(":")[1]
        texts = await get_language(call.from_user.id)
        if len(await db.get_positions(cat_id)) < 1:
            await call.message.delete()
            await call.message.answer(texts.no_products, reply_markup=back_to_user_menu(texts))
        else:
            await call.message.delete()
            cat = await db.get_category(cat_id)
            await call.message.answer(texts.current_cat.format(name=cat['name']),
                                      reply_markup=await open_positions(texts, cat_id))

    @dp.callback_query_handler(text_startswith="open_pod_cat:", state="*")
    async def open_pod_cat(call: CallbackQuery, state: FSMContext):
        await state.finish()

        pod_cat_id = call.data.split(":")[1]
        texts = await get_language(call.from_user.id)
        if len(await db.get_positions(pod_cat_id=pod_cat_id)) < 1:
            await call.message.delete()
            await call.message.answer(texts.no_products)
        else:
            await call.message.delete()
            pod_cat = await db.get_pod_category(pod_cat_id)
            await call.message.answer(texts.current_pod_cat.format(name=pod_cat['name']),
                                      reply_markup=await open_pod_cat_positions(texts, pod_cat_id))

    @dp.callback_query_handler(text_startswith="open_pos:", state="*")
    async def open_pos(call: CallbackQuery, state: FSMContext):
        await state.finish()
        texts = await get_language(call.from_user.id)
        pos_id = call.data.split(":")[1]
        pos = await db.get_position(pos_id)
        cat_id = pos['category_id']
        cat = await db.get_category(cat_id)
        items = f"{len(await db.get_items(position_id=pos_id))}шт."
        if pos['infinity'] == "+":
            items = "Безлимит"
        settings = await db.get_settings()
        if settings['currency'] == 'rub':
            price = pos['price_rub']
        elif settings['currency'] == 'usd':
            price = pos['price_dollar']
        elif settings['currency'] == 'eur':
            price = pos['price_euro']
        msg = texts.open_pos_text.format(cat_name=cat['name'], pos_name=pos['name'], price=price,
                                         cur=currencies[settings['currency']]['sign'], items=items,
                                         desc=pos['description'])

        if pos['photo'] is None or pos['photo'] == "-":
            await call.message.edit_text(msg, reply_markup=await pos_buy_inl(texts, pos_id))
        else:
            await call.message.delete()
            await call.bot.send_photo(chat_id=call.from_user.id, photo=pos['photo'], caption=msg,
                                 reply_markup=await pos_buy_inl(texts, pos_id))

    @dp.callback_query_handler(text_startswith='buy_pos:', state="*")
    async def pos_buy(call: CallbackQuery, state: FSMContext):
        await state.finish()
        texts = await get_language(call.from_user.id)
        pos_id = call.data.split(":")[1]
        pos = await db.get_position(pos_id)
        items = await db.get_items(position_id=pos_id)
        user = await db.get_user(id=call.from_user.id)
        balance, price = 0, 0
        settings = await db.get_settings()
        if settings['currency'] == 'rub':
            balance = user['balance_rub']
            price = pos['price_rub']
        elif settings['currency'] == 'usd':
            balance = user['balance_dollar']
            price = pos['price_dollar']
        elif settings['currency'] == 'eur':
            balance = user['balance_euro']
            price = pos['price_euro']
        await state.update_data(cache_pos_id_for_buy=pos_id)

        if balance < price:
            return await call.answer(texts.no_balance, True)

        if len(items) > 1:
            await call.message.delete()
            await call.message.answer(texts.here_count_products)
            await UserProducts.here_amount_to_buy.set()

        elif len(items) == 1:
            if balance >= price:
                await call.message.delete()
                await call.message.answer(texts.choose_buy_product.format(name=pos['name']),
                                          reply_markup=choose_buy_items(pos_id, 1))
            else:
                await call.answer(texts.no_balance, True)
        else:
            await call.answer(texts.no_product, True)

    @dp.message_handler(state=UserProducts.here_amount_to_buy)
    async def here_amount_to_buy(msg: Message, state: FSMContext):
        amount = msg.text
        user = await db.get_user(id=msg.from_user.id)
        async with state.proxy() as data:
            pos_id = data['cache_pos_id_for_buy']
        texts = await get_language(msg.from_user.id)
        pos = await db.get_position(pos_id)
        settings = await db.get_settings()
        if settings['currency'] == 'rub':
            balance = user['balance_rub']
            price = pos['price_rub']
        elif settings['currency'] == 'usd':
            balance = user['balance_dollar']
            price = pos['price_dollar']
        elif settings['currency'] == 'eur':
            balance = user['balance_euro']
            price = pos['price_euro']
        if not amount.isdigit():
            await msg.delete()
            await msg.answer(texts.no_num_count)
        else:
            if balance >= price:
                await state.finish()
                await msg.delete()
                await msg.answer(texts.choose_buy_products.format(name=pos['name'], amount=amount),
                                 reply_markup=choose_buy_items(pos_id, amount))
            else:
                await msg.reply(texts.no_balance)

    # Подтверждение покупки товара
    @dp.callback_query_handler(text_startswith="buy_items:", state="*")
    async def user_purchase_confirm(call: CallbackQuery, state: FSMContext):
        await state.finish()
        action = call.data.split(":")[1]
        pos_id = call.data.split(":")[2]
        amount = call.data.split(":")[3]
        amount = int(amount)
        texts = await get_language(call.from_user.id)
        settings = await db.get_settings()
        if action == "yes":
            await call.message.edit_text(texts.gen_products)

            pos = await db.get_position(pos_id)
            _type = pos['type']
            items = await db.get_items(position_id=pos_id)
            user = await db.get_user(id=call.from_user.id)
            amount_pay, balance, cur = 0, 0, ""
            if settings['currency'] == "rub":
                cur = "rub"
                balance = user['balance_rub']
                amount_pay = (int(pos['price_rub'] * amount))
            elif settings['currency'] == 'usd':
                cur = "dollar"
                balance = user['balance_dollar']
                amount_pay = (int(pos['price_dollar'] * amount))
            elif settings['currency'] == 'euro':
                cur = "euro"
                balance = user['balance_euro']
                amount_pay = (int(pos['price_euro'] * amount))

            if 1 <= int(amount) <= len(items):
                if balance >= amount_pay:
                    if _type == "text":
                        infinity = pos['infinity']
                        save_items, send_count, split_len = await db.buy_item(items, amount, infinity)

                        if amount != send_count:
                            amount_pay = (float(pos[f'price_{cur}'] * send_count))
                            amount = send_count

                        receipt = get_unix()
                        buy_time = get_date()

                        with suppress(MessageCantBeDeleted):
                            await call.message.delete()
                        if split_len == 0:
                            await call.message.answer("\n\n".join(save_items), parse_mode="None")
                        else:
                            for item in split_messages(save_items, split_len):
                                await call.message.answer("\n\n".join(item), parse_mode="None")
                                await asyncio.sleep(0.3)
                        tovs = "\n".join(save_items)

                        amounts, amount_rub, amount_usd, amount_eur = 0, 0, 0, 0
                        if settings['currency'] == "rub":
                            amount_rub = amount_pay
                            amount_usd = await get_exchange(amount_rub, 'RUB', 'USD')
                            amount_eur = await get_exchange(amount_rub, 'RUB', 'EUR')
                            amounts = amount_rub
                        elif settings['currency'] == 'usd':
                            amount_usd = amount_pay
                            amount_rub = await get_exchange(amount_usd, 'USD', 'RUB')
                            amount_eur = await get_exchange(amount_usd, 'USD', 'EUR')
                            amounts = amount_usd
                        elif settings['currency'] == 'eur':
                            amount_eur = amount_pay
                            amount_rub = await get_exchange(amount_eur, 'EUR', 'RUB')
                            amount_usd = await get_exchange(amount_eur, 'EUR', 'USD')
                            amounts = amount_eur

                        msg = f"""
💰 Новая покупка!
👤 Пользователь: <b>@{user['user_name']}</b> | <a href='tg://user?id={user['id']}'>{user['first_name']}</a> | <code>{user['id']}</code>
💵 Сумма: <code>{amounts}{currencies[settings['currency']]['sign']}</code>
🧾 Чек: <code>{receipt}</code>
⚙️ Товар: <code>{pos['name']}</code>
🤖 Бот: @{(await call.bot.get_me()).username} [<code>{call.bot.id}</code>]
🎲 Содержимое товара:
{tovs}"""
                        await send_admins(msg, True)
                        await db.update_user(user['id'], balance_rub=float(user['balance_rub'] - amount_rub),
                                             balance_dollar=float(user['balance_dollar'] - amount_usd),
                                             balance_euro=float(user['balance_euro'] - amount_eur))
                        await db.add_purchase(user['id'], user['first_name'], user['user_name'], receipt, amount,
                                              amount_rub, amount_usd, amount_eur, pos['id'], pos['name'],
                                              "\n".join(save_items), buy_time, receipt)
                    else:
                        infinity = pos['infinity']
                        save_items, send_count = await db.buy_item_file(items, amount, infinity)

                        if amount != send_count:
                            amount_pay = (float(pos[f'price_{cur}'] * send_count))
                            amount = send_count

                        receipt = get_unix()
                        buy_time = get_date()

                        with suppress(MessageCantBeDeleted):
                            await call.message.delete()

                        for item in save_items:
                            __type = item.split(":")[0]

                            if __type == "photo":
                                await call.message.answer_photo(photo=item.split(":")[1])
                            elif __type == "file":
                                await call.message.answer_document(document=item.split(":")[1])
                            await asyncio.sleep(0.3)

                        amounts, amount_rub, amount_usd, amount_eur = 0, 0, 0, 0
                        if settings['currency'] == "rub":
                            amount_rub = amount_pay
                            amount_usd = await get_exchange(amount_rub, 'RUB', 'USD')
                            amount_eur = await get_exchange(amount_rub, 'RUB', 'EUR')
                            amounts = amount_rub
                        elif settings['currency'] == 'usd':
                            amount_usd = amount_pay
                            amount_rub = await get_exchange(amount_usd, 'USD', 'RUB')
                            amount_eur = await get_exchange(amount_usd, 'USD', 'EUR')
                            amounts = amount_usd
                        elif settings['currency'] == 'eur':
                            amount_eur = amount_pay
                            amount_rub = await get_exchange(amount_eur, 'EUR', 'RUB')
                            amount_usd = await get_exchange(amount_eur, 'EUR', 'USD')
                            amounts = amount_eur

                        msg = f"""
💰 Новая покупка!
👤 Пользователь: <b>@{user['user_name']}</b> | <a href='tg://user?id={user['id']}'>{user['first_name']}</a> | <code>{user['id']}</code>
💵 Сумма: <code>{amounts}{currencies[settings['currency']]['sign']}</code>
🧾 Чек: <code>{receipt}</code>
⚙️ Товар: <code>{pos['name']}</code>
🤖 Бот: @{(await call.bot.get_me()).username} [<code>{call.bot.id}</code>]
🎲 Содержимое товара:"""

                        await send_admins(msg, True)
                        for item in save_items:
                            __type = item.split(":")[0]
                            if __type == "photo":
                                await send_admins(None, True, photo=item.split(":")[1])
                            elif __type == "file":
                                await send_admins(None, True, file=item.split(":")[1])
                            await asyncio.sleep(0.3)

                        await db.update_user(user['id'], balance_rub=float(user['balance_rub'] - amount_rub),
                                             balance_dollar=float(user['balance_dollar'] - amount_usd),
                                             balance_euro=float(user['balance_euro'] - amount_eur))
                        await db.add_purchase(user['id'], user['first_name'], user['user_name'], receipt, amount,
                                              amount_rub, amount_usd, amount_eur, pos['id'], pos['name'],
                                              ",\n".join(save_items), buy_time, receipt)

                    msg = texts.yes_buy_items.format(receipt=receipt, name=pos['name'], amount=amount,
                                                     amount_pay=amounts, cur=currencies[settings['currency']]['sign'],
                                                     buy_time=buy_time)
                    await call.message.answer(msg)
                else:
                    await call.answer(texts.no_balance, True)
            else:
                await call.message.answer(texts.edit_prod)
        else:
            await call.message.edit_text(texts.otmena_buy)

    @dp.callback_query_handler(IsBuy(), text="products:open", state="*")
    async def is_buy(call: CallbackQuery, state: FSMContext):
        await state.finish()
        texts = await get_language(call.from_user.id)
        await call.answer(texts.is_buy_text, True)

    @dp.message_handler(IsBuy(), text=lang_ru.products, state="*")
    @dp.message_handler(IsBuy(), text=lang_en.products, state="*")
    @dp.message_handler(IsBuy(), text=lang_ru.products, state="*")
    async def is_buys(msg: Message, state: FSMContext):
        await state.finish()
        await db.add_users_to_bots(msg.from_user.id, msg.bot.id)
        texts = await get_language(msg.from_user.id)
        await msg.reply(texts.is_buy_text)

    @dp.message_handler(IsContestOn(), text=lang_ru.contest, state="*")
    @dp.message_handler(IsContestOn(), text=lang_en.contest, state="*")
    @dp.message_handler(IsContestOn(), text=lang_ru.contest, state="*")
    async def is_contests_on(msg: Message, state: FSMContext):
        await state.finish()
        await db.add_users_to_bots(msg.from_user.id, msg.bot.id)
        texts = await get_language(msg.from_user.id)
        await msg.reply(texts.is_contests_text)

    @dp.callback_query_handler(IsContestOn(), text_startswith="contest_view:", state="*")
    @dp.callback_query_handler(IsContestOn(), text_startswith="contest_enter:", state="*")
    @dp.callback_query_handler(IsContestOn(), text="contests", state="*")
    async def is_contests_on_(call: CallbackQuery, state: FSMContext):
        await state.finish()
        texts = await get_language(call.from_user.id)
        await call.answer(texts.is_contests_text, True)

    @dp.message_handler(IsBan(), state="*")
    async def is_ban(message: Message, state: FSMContext):
        await state.finish()
        texts = await get_language(message.from_user.id)
        await message.answer(texts.is_ban_text)

    @dp.callback_query_handler(IsBan(), state="*")
    async def is_ban(call: CallbackQuery, state: FSMContext):
        await state.finish()
        texts = await get_language(call.from_user.id)
        await call.answer(texts.is_ban_text)

    @dp.message_handler(IsWork(), state="*")
    async def is_work(message: Message, state: FSMContext):
        await state.finish()
        texts = await get_language(message.from_user.id)
        await message.answer(texts.is_work_text)

    @dp.callback_query_handler(IsWork(), state="*")
    async def is_work(call: CallbackQuery, state: FSMContext):
        await state.finish()
        texts = await get_language(call.from_user.id)
        await call.answer(texts.is_work_text)

    @dp.callback_query_handler(IsRefill(), text="refill", state="*")
    async def is_refill(call: CallbackQuery, state: FSMContext):
        await state.finish()
        texts = await get_language(call.from_user.id)
        await call.answer(texts.is_refill_text, True)

    @dp.message_handler(IsRefill(), text=lang_en.refill, state="*")
    @dp.message_handler(IsRefill(), text=lang_ru.refill, state='*')
    @dp.message_handler(IsRefill(), text=lang_ru.refill, state="*")
    async def is_refill(msg: Message, state: FSMContext):
        await state.finish()
        await db.add_users_to_bots(msg.from_user.id, msg.bot.id)
        texts = await get_language(msg.from_user.id)
        await msg.reply(texts.is_refill_text)

    @dp.callback_query_handler(IsSub(), state="*")
    async def is_subs(call: CallbackQuery, state: FSMContext):
        await state.finish()
        texts = await get_language(call.from_user.id)
        await call.message.answer(texts.no_sub, reply_markup=sub())

    @dp.message_handler(IsSub(), state="*")
    async def is_subs(msg: Message, state: FSMContext):
        await state.finish()
        texts = await get_language(msg.from_user.id)
        await msg.answer(texts.no_sub, reply_markup=sub())

    @dp.callback_query_handler(text=['subprov'])
    async def sub_prov(call: CallbackQuery, state: FSMContext):
        await state.finish()
        if call.message.chat.type == 'private':
            user = await db.get_user(id=call.from_user.id)
            lang = await get_language(call.from_user.id)
            kb = await user_menu(lang, call.from_user.id, True)
            if lang.start_photo == "":
                name = f"@{user['user_name']}"
                if user['user_name'] == "":
                    us = await call.bot.get_chat(user['id'])
                    name = us.get_mention(as_html=True)
                await call.message.answer(lang.start_text.format(user_name=name), reply_markup=kb)
            else:
                name = f"@{user['user_name']}"
                if user['user_name'] == "":
                    us = await call.bot.get_chat(user['id'])
                    name = us.get_mention(as_html=True)
                await call.bot.send_photo(chat_id=call.from_user.id, photo=lang.start_photo,
                                     caption=lang.start_text.format(user_name=name), reply_markup=kb)

    #####################################################################################
    #####################################################################################
    #####################################################################################

    @dp.message_handler(commands=['start'], state="*")
    async def main_start(message: Message, state: FSMContext):
        await state.finish()
        await db.add_users_to_bots(message.from_user.id, message.bot.id)
        user = await db.get_user(id=message.from_user.id)
        lang = await get_language(message.from_user.id)
        kb = await user_menu(lang, message.from_user.id, True)
        s = await db.get_settings()

        if s['is_ref'] == 'True':
            if message.get_args() == "":
                if lang.start_photo == "":
                    name = f"@{user['user_name']}"
                    if user['user_name'] == "":
                        us = await message.bot.get_chat(user['id'])
                        name = us.get_mention(as_html=True)
                    await message.answer(lang.start_text.format(user_name=name), reply_markup=kb)
                else:
                    name = f"@{user['user_name']}"
                    if user['user_name'] == "":
                        us = await message.bot.get_chat(user['id'])
                        name = us.get_mention(as_html=True)
                    await message.answer_photo(photo=lang.start_photo,
                                         caption=lang.start_text.format(user_name=name), reply_markup=kb)
            else:
                if await db.get_user(id=int(message.get_args())) is None:
                    if lang.start_photo == "":
                        name = f"@{user['user_name']}"
                        if user['user_name'] == "":
                            us = await message.bot.get_chat(user['id'])
                            name = us.get_mention(as_html=True)
                        await message.answer(lang.start_text.format(user_name=name), reply_markup=kb)
                    else:
                        name = f"@{user['user_name']}"
                        if user['user_name'] == "":
                            us = await message.bot.get_chat(user['id'])
                            name = us.get_mention(as_html=True)
                        await message.answer_photo(photo=lang.start_photo,
                                             caption=lang.start_text.format(user_name=name), reply_markup=kb)
                else:
                    if user['ref_id'] is not None:
                        await message.answer(lang.yes_reffer)
                    else:
                        reffer = await db.get_user(id=int(message.get_args()))
                        if reffer['id'] == message.from_user.id:
                            await message.answer(lang.invite_yourself)
                        else:
                            user_ref_count = reffer.ref_count
                            msg = lang.new_refferal.format(user_name=user['user_name'],
                                                           user_ref_count=user_ref_count + 1,
                                                           convert_ref=convert_ref(lang, user_ref_count + 1))

                            await db.update_user(message.from_user.id, ref_id=reffer['id'],
                                                 ref_user_name=reffer['user_name'], ref_first_name=reffer['first_name'])
                            await db.update_user(reffer['id'], ref_count=user_ref_count + 1)

                            await message.bot.send_message(chat_id=reffer['id'], text=msg)

                            if reffer['ref_count'] + 1 == s['ref_lvl_1']:
                                remain_refs = s['ref_lvl_2'] - (reffer['ref_count'] + 1)
                                text = lang.new_ref_lvl.format(new_lvl=1, next_lvl=2, remain_refs=remain_refs,
                                                               convert_ref=convert_ref(lang, remain_refs))
                                await message.bot.send_message(chat_id=reffer['id'], text=text)
                                await db.update_user(reffer['id'], ref_lvl=1)
                            elif reffer['ref_count'] + 1 == s['ref_lvl_2']:
                                remain_refs = s['ref_lvl_3'] - (reffer['ref_count'] + 1)
                                text = lang.new_ref_lvl.format(new_lvl=2, next_lvl=3, remain_refs=remain_refs,
                                                               convert_ref=convert_ref(lang, remain_refs))
                                await message.bot.send_message(chat_id=reffer['id'],
                                                       text=text)
                                await db.update_user(reffer['id'], ref_lvl=2)
                            elif reffer['ref_count'] + 1 == s['ref_lvl_3']:
                                await message.bot.send_message(chat_id=reffer['id'],
                                                       text=lang.max_ref_lvl)
                                await db.update_user(reffer['id'], ref_lvl=3)

                            if lang.start_photo == "":
                                name = f"@{user['user_name']}"
                                if user['user_name'] == "":
                                    us = await message.bot.get_chat(user['id'])
                                    name = us.get_mention(as_html=True)
                                await message.answer(lang.start_text.format(user_name=name), reply_markup=kb)
                            else:
                                name = f"@{user['user_name']}"
                                if user['user_name'] == "":
                                    us = await message.bot.get_chat(user['id'])
                                    name = us.get_mention(as_html=True)
                                await message.bot.send_photo(chat_id=message.from_user.id, photo=lang.start_photo,
                                                     caption=lang.start_text.format(user_name=name), reply_markup=kb)
        else:
            if lang.start_photo == "":
                name = f"@{user['user_name']}"
                if user['user_name'] == "":
                    us = await message.bot.get_chat(user['id'])
                    name = us.get_mention(as_html=True)
                await message.answer(lang.start_text.format(user_name=name), reply_markup=kb)
            else:
                name = f"@{user['user_name']}"
                if user['user_name'] == "":
                    us = await message.bot.get_chat(user['id'])
                    name = us.get_mention(as_html=True)
                await message.bot.send_photo(chat_id=message.from_user.id, photo=lang.start_photo,
                                     caption=lang.start_text.format(user_name=name), reply_markup=kb)

    @dp.callback_query_handler(text="ref_system", state='*')
    async def ref_systemm(call: CallbackQuery, state: FSMContext):
        await state.finish()
        s = await db.get_settings()
        status = s['is_ref']
        bott = await call.bot.get_me()
        bot_name = bott.username
        ref_link = f"<code>https://t.me/{bot_name}?start={call.from_user.id}</code>"
        user = await db.get_user(id=call.from_user.id)
        texts = await get_language(call.from_user.id)
        ref_earn_rub = user['ref_earn_rub']
        ref_earn_euro = user['ref_earn_euro']
        ref_earn_dollar = user['ref_earn_dollar']

        if s['currency'] == 'rub':
            ref_earn = ref_earn_rub
        elif s['currency'] == 'usd':
            ref_earn = ref_earn_dollar
        elif s['currency'] == 'eur':
            ref_earn = ref_earn_euro

        ref_count = user['ref_count']
        ref_lvl = user['ref_lvl']
        if ref_lvl == 0:
            lvl = 1
            ref_percent = s['ref_percent_1']
        if ref_lvl == 1:
            lvl = 2
            ref_percent = s['ref_percent_1']
        elif ref_lvl == 2:
            lvl = 3
            ref_percent = s['ref_percent_2']
        elif ref_lvl == 3:
            lvl = 3
            ref_percent = s['ref_percent_3']

        remain_refs = s[f'ref_lvl_{lvl}'] - user['ref_count']

        if ref_lvl == 3:
            mss = texts.cur_max_lvl
        else:
            mss = texts.next_lvl_remain.format(remain_refs=remain_refs)

        reffer_name = user['ref_first_name']
        if reffer_name is None:
            reffer = texts.nobody
        else:
            reffer = f"<a href='tg://user?id={user['ref_id']}'>{reffer_name}</a>"

        curr = currencies[s['currency']]['sign']

        msg = texts.ref_text.format(ref_link=ref_link, ref_percent=ref_percent, reffer=reffer, ref_earn=ref_earn,
                                    curr=curr,
                                    convert_ref=convert_ref(texts, ref_count), ref_count=ref_count, ref_lvl=ref_lvl,
                                    mss=mss)

        if status == "True":
            await call.message.delete()
            await call.message.answer(msg, reply_markup=back_to_profile(texts))
        else:
            await call.answer(texts.is_ref_text, True)

    # Переключение языка
    @dp.callback_query_handler(text='change_language', state="*")
    async def change_language(call: CallbackQuery, state: FSMContext):
        await state.finish()
        texts = await get_language(call.from_user.id)
        await call.message.delete()
        await call.message.answer(texts.choose_language, reply_markup=await choose_languages_kb())

    @dp.callback_query_handler(text_startswith="change_language:", state="*")
    async def change_language_(call: CallbackQuery, state: FSMContext):
        await state.finish()
        lang_short_name = call.data.split(":")[1]

        await db.update_user(id=call.from_user.id, language=lang_short_name)
        await call.message.delete()
        texts = await get_language(call.from_user.id)
        user = await db.get_user(id=call.from_user.id)
        kb = await user_menu(texts, call.from_user.id, True)
        if texts.start_photo == "":
            name = f"@{user['user_name']}"
            if user['user_name'] == "":
                us = await call.bot.get_chat(user['id'])
                name = us.get_mention(as_html=True)
            await call.message.answer(texts.start_text.format(user_name=name), reply_markup=kb)
        else:
            name = f"@{user['user_name']}"
            if user['user_name'] == "":
                us = await call.bot.get_chat(user['id'])
                name = us.get_mention(as_html=True)
            await call.bot.send_photo(chat_id=call.from_user.id, photo=texts.start_photo,
                                 caption=texts.start_text.format(user_name=name), reply_markup=kb)

    # Просмотр истории покупок
    @dp.callback_query_handler(text="last_purchases", state="*")
    async def user_history(call: CallbackQuery, state: FSMContext):
        await state.finish()
        purchasess = await db.last_purchases(call.from_user.id, 10)
        texts = await get_language(call.from_user.id)
        s = await db.get_settings()
        if len(purchasess) >= 1:
            await call.answer(texts.last_10_purc)
            with suppress(MessageCantBeDeleted):
                await call.message.delete()
                for purchases in purchasess:
                    link_items = purchases['item']

                    if s['currency'] == "rub":
                        price = purchases['price_rub']
                    elif s['currency'] == "eur":
                        price = purchases['price_euro']
                    elif s['currency'] == "usd":
                        price = purchases['price_dollar']

                    msg = texts.last_purc_text.format(receipt=purchases['receipt'], name=purchases['position_name'],
                                                      count=purchases['count'], price=price,
                                                      curr=currencies[s['currency']]['sign'],
                                                      date=purchases['date'], link_items=link_items)

                    await call.message.answer(msg)

            await call.message.answer(await open_profile(texts, call), reply_markup=await profile_inl(texts))
        else:
            await call.answer(texts.no_purcs, True)

    @dp.callback_query_handler(text_startswith="promo_act", state="*")
    async def user_history(call: CallbackQuery, state: FSMContext):
        await state.finish()
        await UsersCoupons.here_coupon.set()
        texts = await get_language(call.from_user.id)
        await call.message.delete()
        await call.message.answer(texts.promo_act, reply_markup=back_to_profile(texts))

    @dp.message_handler(state=UsersCoupons.here_coupon)
    async def functions_profile_get(message: Message, state: FSMContext):
        await state.finish()
        s = await db.get_settings()
        coupon = message.text
        texts = await get_language(message.from_user.id)
        if await db.get_coupon_search(coupon=coupon) is None:
            await message.answer(texts.no_coupon.format(coupon=coupon))
        else:
            cop = (await db.get_coupon_search(coupon=coupon))["coupon"]
            uses = (await db.get_coupon_search(coupon=coupon))["uses"]
            discount_rub = (await db.get_coupon_search(coupon=coupon))["discount_rub"]
            discount_eur = (await db.get_coupon_search(coupon=coupon))["discount_euro"]
            discount_usd = (await db.get_coupon_search(coupon=coupon))["discount_dollar"]
            user_id = message.from_user.id
            user = await db.get_user(id=user_id)
            activ_cop = await db.get_activate_coupon(user_id=user_id, coupon_name=cop)
            if uses == 0:
                await message.answer(texts.no_uses_coupon)
                await db.delete_coupon(coupon=coupon)
            elif activ_cop is None:
                bal_eur = user['balance_euro'] + float(discount_eur)
                bal_usd = user['balance_dollar'] + float(discount_usd)
                bal_rub = user['balance_rub'] + float(discount_rub)
                main_discount = 0

                if s['currency'] == "rub":
                    main_discount = discount_rub
                elif s['currency'] == 'eur':
                    main_discount = discount_eur
                elif s['currency'] == 'usd':
                    main_discount = discount_usd

                await db.update_user(user_id, balance_rub=bal_rub, balance_euro=bal_eur, balance_dollar=bal_usd)
                await db.update_coupon(coupon, uses=int(uses) - 1)
                await db.add_activ_coupon(user_id)
                await db.activate_coupon(user_id=user_id, coupon=coupon)
                await message.answer(texts.yes_coupon.format(discount=main_discount,
                                                             curr=currencies[s['currency']]['sign']))
            elif activ_cop["coupon_name"] == cop:
                await message.answer(texts.yes_uses_coupon)

    @dp.callback_query_handler(text="back_to_user_menu", state="*")
    async def again_start(call: CallbackQuery, state: FSMContext):
        await state.finish()
        texts = await get_language(call.from_user.id)
        user = await db.get_user(id=call.from_user.id)
        kb = await user_menu(texts, call.from_user.id, True)
        if texts.start_photo == "":
            name = f"@{user['user_name']}"
            if user['user_name'] == "":
                us = await call.bot.get_chat(user['id'])
                name = us.get_mention(as_html=True)
            await call.message.answer(texts.start_text.format(user_name=name), reply_markup=kb)
        else:
            name = f"@{user['user_name']}"
            if user['user_name'] == "":
                us = await call.bot.get_chat(user['id'])
                name = us.get_mention(as_html=True)
            await call.bot.send_photo(chat_id=call.from_user.id, photo=texts.start_photo,
                                 caption=texts.start_text.format(user_name=name), reply_markup=kb)

    @dp.callback_query_handler(text="profile", state="*")
    async def profile_open(call: CallbackQuery, state: FSMContext):
        await state.finish()
        texts = await get_language(call.from_user.id)
        msg = await open_profile(texts, call)

        await call.message.delete()

        if texts.profile_photo:
            await call.message.answer_photo(photo=texts.profile_photo, caption=msg,
                                            reply_markup=await profile_inl(texts))
        else:
            await call.message.answer(msg, reply_markup=await profile_inl(texts))

    @dp.message_handler(text=lang_en.profile, state="*")
    @dp.message_handler(text=lang_ru.profile, state="*")
    @dp.message_handler(text=lang_ru.profile, state="*")
    async def profile_opens(message: Message, state: FSMContext):
        await state.finish()
        await db.add_users_to_bots(message.from_user.id, message.bot.id)
        texts = await get_language(message.from_user.id)
        msg = await open_profile(texts, message=message)

        await message.delete()

        if texts.profile_photo:
            await message.answer_photo(photo=texts.profile_photo, caption=msg, reply_markup=await profile_inl(texts))
        else:
            await message.answer(msg, reply_markup=await profile_inl(texts))

    @dp.callback_query_handler(text="faq:open", state="*")
    async def faq_open(call: CallbackQuery, state: FSMContext):
        await state.finish()
        s = await db.get_settings()
        texts = await get_language(call.from_user.id)
        faq = s['faq']
        if faq == "None" or faq == "-":
            faq = texts.no_faq_text
        news = s['news']
        chat = s['chat']

        if s['chat'] == "-":
            chat = None

        if s['news'] == "-":
            news = None

        if news is None and chat is None:
            kb = back_to_user_menu(texts)
        if news is None and chat is not None:
            kb = await chat_inl(texts)
        if news is not None and chat is None:
            kb = await news_inl(texts)
        if news is not None and chat is not None:
            kb = await faq_inl(texts)

        await call.message.delete()

        if texts.faq_photo:
            await call.message.answer_photo(photo=texts.faq_photo, caption=faq, reply_markup=kb)
        else:
            await call.message.answer(faq, reply_markup=kb)

    @dp.callback_query_handler(text="support:open", state="*")
    async def faq_open(call: CallbackQuery, state: FSMContext):
        await state.finish()
        s = await db.get_settings()
        texts = await get_language(call.from_user.id)
        get_support = s['support']
        if get_support == "None" or get_support == "-":
            msg = texts.no_support
        else:
            msg = texts.yes_support

        if get_support == "None" or get_support == "-":
            kb = back_to_user_menu(texts)
        else:
            kb = await support_inll()

        await call.message.delete()

        if texts.support_photo:
            await call.message.answer_photo(photo=texts.support_photo, caption=msg, reply_markup=kb)
        else:
            await call.message.answer(msg, reply_markup=kb)

    @dp.callback_query_handler(text="contests", state='*')
    async def contests_view_user(call: CallbackQuery, state: FSMContext):
        await state.finish()
        user = await db.get_user(id=call.from_user.id)
        texts = await get_language(call.from_user.id)
        contests = await db.get_contests()
        if len(contests) > 1:
            await call.message.delete()
            await call.message.answer(text=texts.choose_contest, reply_markup=await choose_contest(contests))
        elif len(contests) == 1:
            await call.message.delete()
            bot_settings = await db.get_settings()
            a = (contests[0]['end_time'] - time.time())
            a1 = datetime.today()
            a2 = a1 + timedelta(seconds=a)
            end_time_ = a2 - a1
            end_time = str(end_time_).split(".")[0]
            if len(end_time.split(",")) == 2:
                day = end_time.split(",")[0]
                day = day.split(" ")[0]
                day_text = convert_words(int(day), texts.day_s)
                end_time = f"{day} {day_text}, {end_time.split(', ')[1]}"
            else:
                end_time = f"{end_time.split(', ')[0]}"

            text = texts.contest_text.format(contests[0]['prize'], currencies[bot_settings["currency"]]["sign"],
                                             end_time, contests[0]['winners_num'],
                                             convert_words(contests[0]["winners_num"],
                                                           texts.winner_s),
                                             contests[0]['members_num'], convert_words(contests[0]["members_num"],
                                                                                       texts.member_s))

            if contests[0]['purchases_num'] > 0 or contests[0]['refills_num'] > 0:
                text += texts.conditions

            status = '❌'

            if contests[0]['refills_num'] > 0:
                if user['count_refills'] >= contests[0]['refills_num']:
                    status = '✅'
                text += texts.conditions_refills.format(num=contests[0]['refills_num'],
                                                        refills=convert_words(contests[0]["refills_num"],
                                                                              texts.refill_s),
                                                        status=status)

            if contests[0]['purchases_num'] > 0:
                if len(await db.get_user_purchases(user['id'])) >= contests[0]['purchases_num']:
                    status = '✅'
                text += texts.conditions_purchases.format(num=contests[0]['purchases_num'],
                                                          purchases=convert_words(contests[0]["purchases_num"],
                                                                                  texts.purchase_s),
                                                          status=status)
            if len(get_channels(contests[0]['channels_ids'])) > 0:
                urls_txt = ''
                ids = get_channels(contests[0]['channels_ids'])

                for c_id in ids:
                    user_status = await bot.get_chat_member(chat_id=c_id, user_id=call.from_user.id)
                    channel = await bot.get_chat(chat_id=c_id)
                    if user_status["status"] == 'left':
                        urls_txt += f"<a href='{channel['invite_link']}'>{channel['title']}</a> - ❌\n"
                    else:
                        urls_txt += f"<a href='{channel['invite_link']}'>{channel['title']}</a> - ✅\n"

                text += "\n\n" + texts.conditions_channels.format(num=len(get_channels(contests[0]['channels_ids'])),
                                                                  channels_text=convert_words(
                                                                      len(get_channels(contests[0]['channels_ids'])),
                                                                      texts.channel_s
                                                                  ), channels=urls_txt)
            if texts.contest_photo == '':
                await call.message.answer(text, reply_markup=await contest_inl(texts, contests[0]['id'], user))
            else:
                await call.message.answer_photo(photo=texts.contest_photo, caption=text,
                                                reply_markup=await contest_inl(texts, contests[0]['id'], user))
        else:
            await call.answer(texts.no_contests, True)

    @dp.message_handler(text=lang_en.contest, state="*")
    @dp.message_handler(text=lang_ru.contest, state="*")
    @dp.message_handler(text=lang_ru.contest, state="*")
    async def contest_user(msg: Message, state: FSMContext):
        await state.finish()
        await db.add_users_to_bots(msg.from_user.id, msg.bot.id)
        user = await db.get_user(id=msg.from_user.id)
        texts = await get_language(msg.from_user.id)
        contests = await db.get_contests()
        if len(contests) > 1:
            await msg.answer(text=texts.choose_contest, reply_markup=await choose_contest(contests))
        elif len(contests) == 1:
            bot_settings = await db.get_settings()
            a = (contests[0]['end_time'] - time.time())
            a1 = datetime.today()
            a2 = a1 + timedelta(seconds=a)
            end_time_ = a2 - a1
            end_time = str(end_time_).split(".")[0]
            if len(end_time.split(",")) == 2:
                day = end_time.split(",")[0]
                day = day.split(" ")[0]
                day_text = convert_words(int(day), texts.day_s)
                end_time = f"{day} {day_text}, {end_time.split(', ')[1]}"
            else:
                end_time = f"{end_time.split(', ')[0]}"

            text = texts.contest_text.format(contests[0]['prize'], currencies[bot_settings["currency"]]["sign"],
                                             end_time, contests[0]['winners_num'],
                                             convert_words(contests[0]["winners_num"],
                                                           texts.winner_s),
                                             contests[0]['members_num'], convert_words(contests[0]["members_num"],
                                                                                       texts.member_s))

            if contests[0]['purchases_num'] > 0 or contests[0]['refills_num'] > 0:
                text += texts.conditions

            status = '❌'

            if contests[0]['refills_num'] > 0:
                if user['count_refills'] >= contests[0]['refills_num']:
                    status = '✅'
                text += texts.conditions_refills.format(num=contests[0]['refills_num'],
                                                        refills=convert_words(contests[0]["refills_num"],
                                                                              texts.refill_s),
                                                        status=status)

            if contests[0]['purchases_num'] > 0:
                if len(await db.get_user_purchases(user['id'])) >= contests[0]['purchases_num']:
                    status = '✅'
                text += texts.conditions_purchases.format(num=contests[0]['purchases_num'],
                                                          purchases=convert_words(contests[0]["purchases_num"],
                                                                                  texts.purchase_s),
                                                          status=status)
            if len(get_channels(contests[0]['channels_ids'])) > 0:
                urls_txt = ''
                ids = get_channels(contests[0]['channels_ids'])

                for c_id in ids:
                    user_status = await bot.get_chat_member(chat_id=c_id, user_id=msg.from_user.id)
                    channel = await bot.get_chat(chat_id=c_id)
                    if user_status["status"] == 'left':
                        urls_txt += f"<a href='{channel['invite_link']}'>{channel['title']}</a> - ❌\n"
                    else:
                        urls_txt += f"<a href='{channel['invite_link']}'>{channel['title']}</a> - ✅\n"

                text += "\n\n" + texts.conditions_channels.format(num=len(get_channels(contests[0]['channels_ids'])),
                                                                  channels_text=convert_words(
                                                                      len(get_channels(contests[0]['channels_ids'])),
                                                                      texts.channel_s
                                                                  ), channels=urls_txt)
            if texts.contest_photo == '':
                await msg.answer(text, reply_markup=await contest_inl(texts, contests[0]['id'], user))
            else:
                await msg.answer_photo(photo=texts.contest_photo, caption=text,
                                       reply_markup=await contest_inl(texts, contests[0]['id'], user))
        else:
            await msg.reply(f"<b>{texts.no_contests}</b>")

    @dp.callback_query_handler(text_startswith="contest_enter:", state="*")
    async def contest_enter(call: CallbackQuery, state: FSMContext):
        await state.finish()

        contest_id = int(call.data.split(":")[1])
        contest_members = await db.get_contest_members_id(contest_id)
        settings = await db.get_settings()
        cur = currencies[settings['currency']]['sign']
        contest = await db.get_contest(contest_id)
        texts = await get_language(call.from_user.id)

        if contest:
            if len(contest_members) == contest['members_num']:
                if call.from_user.id not in contest_members:
                    await call.answer(texts.u_didnt_have_time_to_enter_contest, True)
                return await end_contest(contest_id)
            if call.from_user.id not in contest_members:
                add = await db.add_contest_member(call.from_user.id, contest_id)
                if add:
                    msg = f"""
<b>❗ Юзер {call.from_user.get_mention(as_html=True)} [<code>{call.from_user.id}</code>] участвует в розыгрыше на <code>{contest['prize']}{cur}</code></b>
                    """
                    await send_admins(msg, True)
                    await call.answer(texts.success, True)
                contest_members_new = await db.get_contest_members_id(contest_id)
                if len(contest_members_new) == contest['members_num']:
                    return await end_contest(contest_id)
                else:
                    await call.answer(texts.error, True)
            else:
                await call.answer(texts.u_already_enter_contest, True)
        else:
            await call.answer(texts.contest_already_ended, True)

    @dp.callback_query_handler(text_startswith="mail_contest_view:", state="*")
    @dp.callback_query_handler(text_startswith="contest_view:", state="*")
    async def contest_view(call: CallbackQuery, state: FSMContext):
        await state.finish()
        texts = await get_language(call.from_user.id)
        user = await db.get_user(id=call.from_user.id)
        contest_id = call.data.split(":")[1]
        contest = await db.get_contest(contest_id)
        bot_settings = await db.get_settings()
        a = (contest['end_time'] - time.time())
        a1 = datetime.today()
        a2 = a1 + timedelta(seconds=a)
        end_time_ = a2 - a1
        end_time = str(end_time_).split(".")[0]
        if len(end_time.split(",")) == 2:
            day = end_time.split(",")[0]
            day = day.split(" ")[0]
            day_text = convert_words(int(day), texts.day_s)
            end_time = f"{day} {day_text}, {end_time.split(', ')[1]}"
        else:
            end_time = f"{end_time.split(', ')[0]}"

        text = texts.contest_text.format(contest['prize'], currencies[bot_settings["currency"]]["sign"],
                                         end_time, contest['winners_num'],
                                         convert_words(contest["winners_num"],
                                                       texts.winner_s),
                                         contest['members_num'], convert_words(contest["members_num"],
                                                                               texts.member_s))

        if contest['purchases_num'] > 0 or contest['refills_num'] > 0:
            text += texts.conditions

        status = '❌'

        if contest['refills_num'] > 0:
            if user['count_refills'] >= contest['refills_num']:
                status = '✅'
            text += texts.conditions_refills.format(num=contest['refills_num'],
                                                    refills=convert_words(contest["refills_num"],
                                                                          texts.refill_s),
                                                    status=status)

        if contest['purchases_num'] > 0:
            if len(await db.get_user_purchases(user['id'])) >= contest['purchases_num']:
                status = '✅'
            text += texts.conditions_purchases.format(num=contest['purchases_num'],
                                                      purchases=convert_words(contest["purchases_num"],
                                                                              texts.purchase_s),
                                                      status=status)

        if len(get_channels(contest['channels_ids'])) > 0:
            urls_txt = ''
            ids = get_channels(contest['channels_ids'])

            for c_id in ids:
                user_status = await bot.get_chat_member(chat_id=c_id, user_id=call.from_user.id)
                channel = await bot.get_chat(chat_id=c_id)
                if user_status["status"] == 'left':
                    urls_txt += f"<a href='{channel['invite_link']}'>{channel['title']}</a> - ❌\n"
                else:
                    urls_txt += f"<a href='{channel['invite_link']}'>{channel['title']}</a> - ✅\n"

            text += "\n\n" + texts.conditions_channels.format(num=len(get_channels(contest['channels_ids'])),
                                                              channels_text=convert_words(
                                                                  len(get_channels(contest['channels_ids'])),
                                                                  texts.channel_s
                                                              ), channels=urls_txt)

        if call.data.split(":")[0] == "contest_view":
            if texts.contest_photo == '':
                await call.message.edit_text(text, reply_markup=await contest_inl(texts, contest['id'], user))
            else:
                await call.message.delete()
                await call.message.answer_photo(photo=texts.contest_photo, caption=text,
                                                reply_markup=await contest_inl(texts, contest['id'], user))
        else:
            if texts.contest_photo == '':
                await call.message.answer(text, reply_markup=await contest_inl(texts, contest['id'], user))
            else:
                await call.message.answer_photo(photo=texts.contest_photo, caption=text,
                                                reply_markup=await contest_inl(texts, contest['id'], user))

    @dp.message_handler(text=lang_ru.faq, state="*")
    @dp.message_handler(text=lang_ru.faq, state="*")
    @dp.message_handler(text=lang_en.faq, state="*")
    async def faq_opens(message: Message, state: FSMContext):
        await state.finish()
        await db.add_users_to_bots(message.from_user.id, message.bot.id)
        texts = await get_language(message.from_user.id)
        s = await db.get_settings()
        faq = s['faq']
        if faq == "None" or faq == "-":
            faq = texts.no_faq_text
        news = s['news']
        chat = s['chat']

        if s['chat'] == "-":
            chat = None

        if s['news'] == "-":
            news = None

        if news is None and chat is None:
            kb = back_to_user_menu(texts)
        if news is None and chat is not None:
            kb = await chat_inl(texts)
        if news is not None and chat is None:
            kb = await news_inl(texts)
        if news is not None and chat is not None:
            kb = await faq_inl(texts)

        await message.delete()

        if texts.faq_photo:
            await message.answer_photo(photo=texts.faq_photo, caption=faq, reply_markup=kb)
        else:
            await message.answer(faq, reply_markup=kb)

    @dp.message_handler(text=lang_ru.support, state="*")
    @dp.message_handler(text=lang_ru.support, state="*")
    @dp.message_handler(text=lang_en.support, state="*")
    async def faq_opens(message: Message, state: FSMContext):
        await state.finish()
        await db.add_users_to_bots(message.from_user.id, message.bot.id)
        texts = await get_language(message.from_user.id)
        supports = await db.get_supports()
        if len(supports) == 0:
            msg = texts.no_support
            kb = back_to_user_menu(texts)
        else:
            msg = texts.yes_support
            kb = await support_inll()

        await message.delete()

        if texts.support_photo:
            await message.answer_photo(photo=texts.support_photo, caption=msg, reply_markup=kb)
        else:
            await message.answer(msg, reply_markup=kb)

    @dp.message_handler(text=lang_ru.refill, state="*")
    @dp.message_handler(text=lang_ru.refill, state="*")
    @dp.message_handler(text=lang_en.refill, state="*")
    async def refill_opens(message: Message, state: FSMContext):
        await state.finish()
        await db.add_users_to_bots(message.from_user.id, message.bot.id)
        texts = await get_language(message.from_user.id)
        await message.delete()

        if texts.refill_photo:
            await message.answer_photo(photo=texts.refill_photo, caption=texts.refill_text,
                                       reply_markup=await refill_inl(texts))
        else:
            await message.answer(texts.refill_text, reply_markup=await refill_inl(texts))

    @dp.message_handler(text=lang_ru.products, state="*")
    @dp.message_handler(text=lang_ru.products, state="*")
    @dp.message_handler(text=lang_en.products, state="*")
    async def open_products_users(message: Message, state: FSMContext):
        await state.finish()
        await db.add_users_to_bots(message.from_user.id, message.bot.id)
        texts = await get_language(message.from_user.id)
        shops = await db.get_shops()
        if len(shops) < 1:
            await message.delete()
            if texts.products_photo:
                await message.answer_photo(photo=texts.products_photo, caption=texts.no_cats,
                                           reply_markup=back_to_user_menu(texts))
            else:
                await message.answer(texts.no_cats, reply_markup=back_to_user_menu(texts))
        else:
            await message.delete()
            if texts.products_photo:
                await message.answer_photo(photo=texts.products_photo, caption=texts.available_cats,
                                           reply_markup=open_shops(texts, shops))
            else:
                await message.answer(texts.available_cats, reply_markup=open_shops(texts, shops))

    @dp.message_handler(IsAdmin(), commands=['admin', 'adm', 'a'], state="*")
    async def admin_menu_send(message: Message, state: FSMContext):
        await state.finish()

        await message.answer("Добро пожаловать в меню Администратора", reply_markup=admin_menu())

    @dp.message_handler(IsAdmin(), text='⚙️ Меню Администратора', state="*")
    async def admin_menu_send(message: Message, state: FSMContext):
        await state.finish()
        await message.answer("Добро пожаловать в меню Администратора:", reply_markup=admin_menu())

    @dp.message_handler(IsPosAdmin(), text='⚙️ Меню Администратора', state="*")
    async def admin_menu_send1(message: Message, state: FSMContext):
        await state.finish()
        await message.answer("Добро пожаловать в меню Администратора:", reply_markup=pos_admin_menu())

    @dp.message_handler(IsShopAdmin(), text='⚙️ Меню Администратора', state="*")
    async def admin_menu_send1(message: Message, state: FSMContext):
        await state.finish()
        await message.answer("Добро пожаловать в меню Администратора:", reply_markup=shop_admin_menu())

    # Разбив списка по количеству переданных значений
    def split_messages(get_list, count):
        return [get_list[i:i + count] for i in range(0, len(get_list), count)]

    # Проверка товаров в наличии
    @dp.message_handler(text=lang_en.nal_products, state="*")
    @dp.message_handler(text=lang_ru.nal_products, state="*")
    @dp.message_handler(text=lang_ru.nal_products, state="*")
    async def user_available_(message: Message, state: FSMContext):
        await state.finish()
        shops = await db.get_shops()
        await message.answer("<b>❗ Выберите магазин:</b>", reply_markup=nal_products_shops(shops))

    @dp.callback_query_handler(text_startswith="nal_products:", state='*')
    async def user_available(call: CallbackQuery, state: FSMContext):
        await state.finish()
        shop_id = call.data.split(":")[1]
        texts = await get_language(call.from_user.id)

        get_categories = await db.get_categories(shop_id)
        save_items = []

        for category in get_categories:
            get_positions = await db.get_positions(cat_id=category['id'])
            this_items = []

            if len(get_positions) >= 1:
                this_items = [f"<b>➖➖➖ {category['name']} ➖➖➖</b>"]

                for position in get_positions:
                    get_items = await db.get_items(position_id=position['id'])

                    if len(get_items) >= 1:
                        this_items.append(
                            f"{position['name']} | {position['price_rub']}₽ | В наличии {len(get_items)} шт")

            if len(this_items) >= 2:
                save_items.append(this_items)

        if len(save_items) >= 1:
            send_items = ":^^^^^:".join(["\n".join(item) for item in save_items])

            if len(send_items) > 3500:
                split_items = split_messages(send_items.split("\n"), 40)

                for item in split_items:
                    await call.message.edit_text("\n".join(item).replace(":^^^^^:", "\n\n"),
                                                 reply_markup=custom_btn("nal_products"))
            else:
                await call.message.edit_text("\n\n".join(["\n".join(item) for item in save_items]),
                                             reply_markup=custom_btn("nal_products"))
        else:
            await call.message.edit_text(texts.nal_no_products_text,
                                         reply_markup=custom_btn("nal_products"))

    @dp.callback_query_handler(text="nal_products", state="*")
    async def user_available(call: CallbackQuery, state: FSMContext):
        await state.finish()
        shops = await db.get_shops()
        try:
            await call.message.edit_text("<b>❗ Выберите магазин:</b>", reply_markup=nal_products_shops(shops))
        except:
            await call.message.answer("<b>❗ Выберите магазин:</b>", reply_markup=nal_products_shops(shops))

    @dp.message_handler()
    async def pr_buttons1(msg: Message, state: FSMContext):
        pr_buttons = await db.get_all_pr_buttons()
        await state.finish()
        for button in pr_buttons:
            if msg.text == button['name']:
                if button['photo'] != '-':
                    await msg.answer_photo(photo=button['photo'], caption=button['txt'])
                else:
                    await msg.answer(button['txt'])

    @dp.callback_query_handler(text_startswith='pr_button_user:', state='*')
    async def pr_buttons2(call: CallbackQuery, state: FSMContext):
        await state.finish()
        b_id = int(call.data.split(':')[1])
        btn = await db.get_pr_button(b_id)
        texts = await get_language(call.from_user.id)
        if btn['photo'] == '-':
            await call.message.delete()
            await call.message.answer(btn['txt'], reply_markup=back_to_user_menu(texts))
        else:
            await call.message.delete()
            await call.message.answer_photo(photo=btn['photo'], caption=btn['txt'],
                                            reply_markup=back_to_user_menu(texts))


class BotManager:
    def __init__(self, bots_list: dict):
        self.bots_list: dict = bots_list

    async def run_all_bots(self):
        for _bot in self.bots_list.values():
            asyncio.create_task(self._start_bot(_bot))
        return True

    async def _stop_bot(self, _bot):
        dp: Dispatcher = _bot['dp']
        dp.stop_polling()
        await dp.wait_closed()
        return True

    async def add_bot_to_list_and_run(self, _bot: dict):
        self.bots_list[_bot['id']] = _bot
        asyncio.create_task(self._start_bot(_bot, True))
        return True

    async def get_bot_info(self, bot_token: str):
        try:
            bot_ = Bot(token=bot_token)
            _bot = await bot_.get_me()
            return _bot.id, _bot.username
        except:
            return None, None

    async def _start_bot(self, bot_: dict, is_first_start=False):
        dp = self.bots_list.get(bot_['id']).get('dp')
        if dp:
            return False
        _bot = Bot(token=bot_['token'], parse_mode="HTML", disable_web_page_preview=True)
        dp = Dispatcher(_bot, storage=MemoryStorage())
        bot_['dp'] = dp
        bot_['bot'] = _bot
        self.bots_list[bot_['id']] = bot_
        setup_middlewares(dp)
        handlers(dp)

        try:
            if is_first_start:
                await _bot.send_message(bot_['owner_id'], "<b>✅ Бот запущен.</b>")
        except:
            pass
        await dp.skip_updates()
        await dp.start_polling()

    async def delete_and_stop_bot_from_list(self, _bot: dict):
        try:
            bot_ = self.bots_list.pop(_bot['id'])
            dp: Dispatcher = bot_['dp']
            dp.stop_polling()
            await dp.wait_closed()
            return True
        except Exception as e:
            print(e)
            return False

    async def run_bot(self, _bot: dict):
        try:
            dp: Dispatcher = _bot['dp']
            dp.stop_polling()
            return True
        except Exception as e:
            print(e)
            return False

    async def stop_bot(self, _bot: dict):
        try:
            dp: Dispatcher = _bot['dp']
            dp.stop_polling()
            await dp.wait_closed()
            return True
        except Exception as e:
            print(e)
            return False


bots_ = {}

async def main():
    bots = await db.get_all_bots()
    for bot_ in bots:
        bots_[bot_['id']] = bot_

asyncio.run(main())

BM = BotManager(bots_)
