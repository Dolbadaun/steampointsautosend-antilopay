# tgbot/utils/points_confirm.py
from decimal import Decimal, ROUND_HALF_UP
from urllib.parse import urlparse, urlunparse, parse_qsl, urlencode

SCALE = Decimal("0.001")

def _money(x) -> Decimal:
    return (Decimal(str(x))).quantize(SCALE, rounding=ROUND_HALF_UP)

def _fmt_int_with_spaces(n: int) -> str:
    s = f"{int(n)}"
    return " ".join([s[max(i-3,0):i] for i in range(len(s), 0, -3)][::-1])

def awards_link(steam_url: str) -> str:
    try:
        u = urlparse((steam_url or '').strip())
        if not u.scheme:
            u = u._replace(scheme='https')
        if 'steamcommunity.com' not in (u.netloc or ''):
            return steam_url or ''
        q = dict(parse_qsl(u.query, keep_blank_values=True))
        q['awards'] = '1'
        u = u._replace(query=urlencode(q))
        u = u._replace(fragment='awards')
        return urlunparse(u)
    except Exception:
        return steam_url or ''

def build_confirmation(steam_url: str, amount_rub, points_qty: int, points_before: int | None) -> str:
    total = _money(amount_rub)
    url = awards_link(steam_url)
    before = int(points_before or 0)
    after = before + int(points_qty)
    before_s = _fmt_int_with_spaces(before)
    after_s  = _fmt_int_with_spaces(after)
    return (
        '✅ Покупка оформлена!\n'
        f'{url}\n'
        f'Сумма: ₽{total:.3f}\n'
        f'Количество поинтов: {int(points_qty)}\n'
        f'До: {before_s}\n'
        f'После: {after_s}\n'
        'Спасибо за покупку.'
    )
