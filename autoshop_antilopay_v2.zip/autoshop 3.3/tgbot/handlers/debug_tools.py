# tgbot/handlers/debug_tools.py
from aiogram.types import Message
from aiogram.dispatcher import FSMContext
from tgbot.data.loader import dp
from tgbot.data.config import db
import json

@dp.message_handler(commands=["debug_cats"], state="*")
async def debug_cats(message: Message, state: FSMContext):
    await state.finish()
    rows = await db.get_all_categories()
    lines = [f"{row.get('id')} | {row.get('name')}" for row in rows]
    if not lines:
        await message.answer("categories: 0")
    else:
        await message.answer("categories: " + str(len(lines)) + "\n" + "\n".join(lines))

@dp.message_handler(commands=["debug_pos"], state="*")
async def debug_pos(message: Message, state: FSMContext):
    await state.finish()
    parts = message.text.split()
    cat_id = parts[1] if len(parts) > 1 else None
    if not cat_id:
        await message.answer("Usage: /debug_pos <cat_id>")
        return
    rows = await db.get_positions(cat_id)
    lines = [f"{row.get('id')} | {row.get('name')} | cat={row.get('category')}" for row in rows]
    await message.answer("positions: " + str(len(lines)) + "\n" + "\n".join(lines))
