# - *- coding: utf- 8 - *-
from aiogram import Dispatcher

from .points_buy import dp
from .force_catalog import dp
from .debug_tools import dp
from .main_start import dp
from .admin_functions import dp
from .users_refills import dp
from .admin_payments import dp
from .admin_products import dp
from .user_products import dp
from .errors import dp

__all__ = ['dp']
