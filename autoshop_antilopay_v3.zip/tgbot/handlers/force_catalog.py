# tgbot/handlers/force_catalog.py  (force direct product open)
import logging
from aiogram.dispatcher import FSMContext
from aiogram.types import Message
from aiogram.utils.exceptions import BadRequest

from tgbot.data.loader import dp
from tgbot.keyboards.inline_user import back_to_user_menu, pos_buy_inl
from tgbot.data.config import db, currencies

# ---- Robust get_language import with fallbacks ----
try:
    from tgbot.utils.utils_functions import get_language as _get_language
    async def get_language(user_id: int):
        return await _get_language(user_id)
except Exception:
    from tgbot.data.languages import ru as _ru
    async def get_language(user_id: int):
        return _ru.Texts()

DEFAULT_POS_ID = 1762013060538514700

async def _open_direct_message(message: Message, user_id: int):
    texts = await get_language(user_id)
    settings = await db.get_settings()
    pos = await db.get_position(DEFAULT_POS_ID)
    if not pos:
        await message.answer(texts.no_products, reply_markup=back_to_user_menu(texts))
        return
    pos_id = pos['id']
    cat = await db.get_category(pos['category_id'])
    items = f"{len(await db.get_items(position_id=pos_id))}шт."
    if pos['infinity'] == '+':
        items = 'Безлимит'
    field = 'price_rub' if settings['currency'] == 'rub' else ('price_dollar' if settings['currency']=='usd' else 'price_euro')
    cur_sign = currencies[settings['currency']]['sign']
    price_val = pos[field]
    msg = texts.open_pos_text.format(cat_name=cat['name'], pos_name=pos['name'], price=price_val,
                                     cur=cur_sign, items=items, desc=pos['description'])
    if pos['photo'] is None or pos['photo'] == '-':
        await message.answer(msg, reply_markup=await pos_buy_inl(texts, pos_id))
    else:
        await message.answer_photo(photo=pos['photo'], caption=msg, reply_markup=await pos_buy_inl(texts, pos_id))

@dp.message_handler(commands=["catalog", "cat", "products"], state=None)
async def products_cmd(message: Message, state: FSMContext):
    await state.finish()
    await _open_direct_message(message, message.from_user.id)

@dp.message_handler(lambda m: isinstance(m.text, str) and not m.text.startswith('/') and (('куп' in m.text.lower()) or ('buy' in m.text.lower())), state=None)
async def products_text(message: Message, state: FSMContext):
    await state.finish()
    await _open_direct_message(message, message.from_user.id)
