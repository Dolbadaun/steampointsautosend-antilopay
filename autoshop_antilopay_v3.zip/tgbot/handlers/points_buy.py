
# === BEGIN: .env support (no extra deps) ===
import os
from pathlib import Path

def _read_env_var(var_name: str) -> str | None:
    """Читает переменную из os.environ или из .env файла"""
    # Try environment first
    raw = os.environ.get(var_name)
    if raw is not None:
        return raw
    # Fallback: try reading .env located at project root
    try:
        root = Path(__file__).resolve().parents[2]
        env_path = root / ".env"
        if env_path.exists():
            for line in env_path.read_text(encoding="utf-8", errors="ignore").splitlines():
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, val = line.split("=", 1)
                if key.strip() == var_name:
                    return val.strip()
    except Exception:
        pass
    return None

def _read_points_unit_price_override() -> float | None:
    raw = _read_env_var("POINTS_UNIT_PRICE_OVERRIDE")
    if raw is None:
        return None
    # Normalize decimal separator
    raw = raw.replace(",", ".")
    try:
        v = float(raw)
        if v > 0:
            return v
    except Exception:
        pass
    return None
# === END: .env support ===

# -*- coding: utf-8 -*-
"""
tgbot/handlers/points_buy.py

Сценарии:
1) /buy <кол-во> — детали счета → ждём ссылку → создаём заказ
2) Кнопка «Купить» (callback: points:start:<pos_id>) — спросить количество → как в (1)
Дополнения:
- Валидируем кратность 100
- Кнопка «❌ Отменить» в валидационных сообщениях и «Деталях счёта», возвращает к карточке товара
- Парсим очки «до» со страницы /awards, приоритетно из скобок "Всего получено: … (NNN очк. Steam)"
- Ссылка на награды без ?l=russian (только /awards)
- В карточке товара нет кнопки «Вернуться», только «Купить»
"""
import os
import re
import configparser
from typing import Optional


def unit_price_for_api(default_value: float) -> float:
    """Возвращает число для buy_unit_price из ENV/ini, иначе default_value."""
    try:
        val = os.getenv('POINTS_UNIT_PRICE_OVERRIDE', '').strip()
        if val:
            return float(val)
    except Exception:
        pass
    try:
        cfg = configparser.ConfigParser()
        if os.path.exists('settings.ini'):
            cfg.read('settings.ini', encoding='utf-8')
            if cfg.has_section('points') and cfg.has_option('points', 'unit_price_override'):
                v = cfg.get('points', 'unit_price_override').strip()
                if v:
                    return float(v)
    except Exception:
        pass
    return float(default_value)




import aiohttp
from loguru import logger as log
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from tgbot.data.loader import dp
from tgbot.data.config import db, currencies
from tgbot.utils.utils_functions import send_admins

# Язык
try:
    from tgbot.utils.utils_functions import get_language
except Exception:
    from tgbot.data.languages import ru as _ru
    async def get_language(user_id: int):
        return _ru.Texts()

# Баланс и курсы
try:
    from tgbot.utils.utils_functions import update_balance, get_exchange
except Exception:
    update_balance = None
    async def get_exchange(amount: float, from_ccy: str, to_ccy: str) -> float:
        return float(amount)

# Состояния
try:
    from tgbot.states.users import PointsBuy  # type: ignore
except Exception:
    from aiogram.dispatcher.filters.state import StatesGroup, State
    class PointsBuy(StatesGroup):  # type: ignore
        waiting_amount = State()
        waiting_link = State()

# .env
try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass

DEFAULT_POS_ID = 1762013060538514700   # Товар: «Стим очки Автовыдача цена за 1 шт»
POINTS_STEP = 100                      # кратность по требованию
POINTS_API_BASE = _read_env_var('POINTS_API_BASE') or 'https://yuanyoumao.com'
SITE_TOKEN = (_read_env_var('SITE_TOKEN') or '').strip()


# ========================= helpers =========================
def _awards_url(steam_link: str) -> str:
    steam_link = steam_link.strip().rstrip('/')
    return f"{steam_link}/awards"



async def _fetch_awards_points(steam_link: str) -> Optional[int]:
    """
    Возвращает число очков со страницы /awards.
    Приоритет: значение в скобках из строки вида:
      RU: "Всего получено: 46 (16 300 очк. Steam)"
      EN: "Total Received: 46 (16,300 Steam Points)"
    Разрешаем HTML-теги внутри скобок, разные пробелы/разделители.
    Если не нашли — используем подписи RU/EN и общий fallback.
    """
    url = _awards_url(steam_link)
    try:
        timeout = aiohttp.ClientTimeout(total=10)
        headers = {"Accept-Language": "ru,en;q=0.8", "User-Agent": "Mozilla/5.0"}
        async with aiohttp.ClientSession(timeout=timeout, headers=headers) as session:
            async with session.get(url) as resp:
                text = await resp.text()
                log.debug(f"STEAM AWARDS GET {url} -> {resp.status}")

                def _clean_int(s: str) -> Optional[int]:
                    digits = re.sub(r"[^0-9]", "", s)
                    return int(digits) if digits.isdigit() else None

                # 1) Strict RU/EN: "... (NNN очк. Steam)" or "(NNN Steam Points)"
                strict_patterns = [
                    r"Всего\s*получено[^()]*\(\s*(?:<[^>]+>\s*)*([\d\s\u202f\u00a0,\.]+)(?:\s*</[^>]+>)*\s*(?:очк\.?\s*Steam|очков\s*Steam)\s*\)",
                    r"Total\s*Received[^()]*\(\s*(?:<[^>]+>\s*)*([\d\s\u202f\u00a0,\.]+)(?:\s*</[^>]+>)*\s*(?:Steam\s*Points|points)\s*\)",
                ]
                for pat in strict_patterns:
                    m = re.search(pat, text, re.IGNORECASE | re.DOTALL)
                    if m:
                        val = _clean_int(m.group(1))
                        if isinstance(val, int):
                            log.debug(f"Parsed Steam points (total/paren strict) at {url}: {val}")
                            return val

                # 2) Labels RU/EN near number
                m = re.search(r"(?:Очки\s*Steam|Баланс\s*очков|Steam\s*Points)[^0-9]{0,60}([\d\s\u202f\u00a0,\.]+)", text, re.IGNORECASE)
                if not m:
                    m = re.search(r">([\d\s\u202f\u00a0,\.]{2,})</[^>]*>\s*<(?:[^>]+>){0,3}(?:Очки\s*Steam|Steam\s*Points)", text, re.IGNORECASE)
                if m:
                    val = _clean_int(m.group(1))
                    if isinstance(val, int):
                        log.debug(f"Parsed Steam points (label) at {url}: {val}")
                        return val

                # 3) Fallback: max reasonable number
                candidates = []
                for num_txt in re.findall(r"(?<!\d)(\d[\d\s\u202f\u00a0,\.]{2,})", text):
                    val = _clean_int(num_txt)
                    if isinstance(val, int) and 0 < val < 10_000_000_000:
                        candidates.append(val)
                if candidates:
                    best = max(candidates)
                    log.debug(f"Parsed Steam points (fallback) at {url}: {best}")
                    return best
    except Exception as e:
        log.warning("AWARDS parse failed: %r", e)
    return None


async def _get_settings_currency_key() -> str:
    settings = await db.get_settings()
    cur = settings.get('currency', 'rub')
    if cur not in ('rub', 'usd', 'eur'):
        cur = 'rub'
    return cur


async def _get_position_price(pos_id: int, cur: str) -> float:
    pos = await db.get_position(pos_id)
    if not pos:
        return 0.0
    field = 'price_rub' if cur == 'rub' else ('price_dollar' if cur == 'usd' else 'price_euro')
    try:
        return float(pos.get(field) or 0)
    except Exception:
        return 0.0


async def _get_user_balance(user_id: int, cur: str) -> float:
    # Баланс в базе в RUB
    user = await db.get_user(id=user_id)
    rub_balance = float(user.get('balance_rub') or 0.0)
    if cur == 'rub':
        return rub_balance
    try:
        return float(await get_exchange(rub_balance, 'RUB', cur.upper()))
    except Exception:
        return rub_balance


async def _deduct_from_balance(user_id: int, cur: str, cost_cur: float) -> bool:
    """Списывает из баланса сумму cost_cur в валюте cur (в БД — в рублях)."""
    try:
        if update_balance is None:
            return True
        if cur == "rub":
            amount_rub = float(cost_cur)
        else:
            amount_rub = float(await get_exchange(cost_cur, cur.upper(), "RUB"))
        await update_balance(user_id=user_id, amount=amount_rub, add=False)
        return True
    except Exception as e:
        log.exception("Failed to deduct balance: %r", e)
        return False


def _idempotency_key(user_id: int, steam_link: str, amount: int) -> str:
    return f"{user_id}|{steam_link}|{amount}"


async def _create_points_order(*, user_id: int, steam_link: str, amount: int, unit_price: float) -> (bool, dict):
    if not SITE_TOKEN:
        log.error("SITE_TOKEN is empty → 401 неизбежен. Проверь .env/переменные окружения.")
        return False, {"error": "SITE_TOKEN_IS_EMPTY"}

    url = f"{POINTS_API_BASE}/api/points/buy/generateBuyOfferPayOrder"
    payload = {
        "agree": True,
        "buy_count": int(amount),
        "buy_steam_id": steam_link,
        "buy_unit_price": unit_price_for_api(float(unit_price) if unit_price else 1.0),
        "pay_type": "account_balance",
    }
    headers = {
        "Cookie": f"token={SITE_TOKEN}",
        "Accept": "application/json",
        "Content-Type": "application/json",
        "X-Idempotency-Key": _idempotency_key(user_id, steam_link, amount),
    }

    timeout = aiohttp.ClientTimeout(total=15)
    try:
        async with aiohttp.ClientSession(timeout=timeout) as session:
            log.debug(f"REQ payload={payload} headers={{'Cookie': '<hidden>', ...}}")
            log.debug(f"REQ POST {url}")
            async with session.post(url, json=payload, headers=headers) as resp:
                text = await resp.text()
                log.debug(f"RESP {resp.status} {'OK' if resp.status == 200 else ''}: {text}")
                ok = resp.status == 200
                try:
                    data = await resp.json(content_type=None)
                except Exception:
                    data = {"raw": text}
                if ok and isinstance(data, dict) and data.get("code") == 0:
                    return True, data
                return False, data
    except Exception as e:
        log.exception("Order request failed: %r", e)
        return False, {"error": "REQUEST_FAILED", "ex": str(e)}


# ====================== UI helpers ======================
def _cancel_kb() -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup()
    kb.add(InlineKeyboardButton(text="❌ Отменить", callback_data="points:cancel"))
    return kb


async def _send_product_card(chat_id: int, user_id: int, pos_id: int = None):
    pos_id = int(pos_id or DEFAULT_POS_ID)
    texts = await get_language(user_id)
    settings = await db.get_settings()
    pos = await db.get_position(pos_id)
    if not pos:
        await dp.bot.send_message(chat_id, "Товар недоступен.")
        return
    cat = await db.get_category(pos['category_id'])

    try:
        items_count = len(await db.get_items(position_id=pos_id))
        items = f"{items_count}шт."
    except Exception:
        items = "Безлимит" if pos.get('infinity') == '+' else "—"
    if pos.get('infinity') == '+':
        items = 'Безлимит'

    field = 'price_rub' if settings['currency'] == 'rub' else ('price_dollar' if settings['currency']=='usd' else 'price_euro')
    cur_sign = currencies[settings['currency']]['sign']
    price_val = pos[field]

    # Текст карточки берём из языковых шаблонов, как в проекте
    try:
        msg = texts.open_pos_text.format(
            cat_name=cat['name'], pos_name=pos['name'],
            price=price_val, cur=cur_sign, items=items, desc=pos['description']
        )
    except Exception:
        # Фолбэк
        msg = (f"💎 Категория: {cat['name']}\n\n"
               f"🛍️ Товар: {pos['name']}\n💰 Стоимость: {price_val}{cur_sign}\n"
               f"⚙️ Количество: {items}\n🎲 Описание:\n{pos['description']}")

    # Оставляем только кнопку «Купить»
    kb = InlineKeyboardMarkup()
    buy_text = getattr(texts, "open_pos_buy", None) or getattr(texts, "open_pos_btn_buy", None) or "🎁 Купить"
    kb.add(InlineKeyboardButton(text=buy_text, callback_data=f"points:start:{pos_id}"))

    if pos.get('photo') in (None, '-'):
        await dp.bot.send_message(chat_id, msg, reply_markup=kb)
    else:
        await dp.bot.send_photo(chat_id=chat_id, photo=pos['photo'], caption=msg, reply_markup=kb)


# ========================= /buy =========================
@dp.message_handler(commands=["buy"], state=None)
async def cmd_buy(message: types.Message, state: FSMContext):
    await state.finish()
    parts = (message.text or "").split()
    if len(parts) < 2:
        await message.answer("Укажите количество очков: /buy 100", reply_markup=_cancel_kb())
        return

    # количество
    try:
        amount = int(parts[1].replace(" ", ""))
    except Exception:
        await message.answer("Количество должно быть целым числом. Пример: 1000", reply_markup=_cancel_kb())
        return
    if amount <= 0 or amount % POINTS_STEP != 0:
        await message.answer(f"Количество должно быть положительным и кратным {POINTS_STEP}.", reply_markup=_cancel_kb())
        return

    pos_id = DEFAULT_POS_ID
    cur = await _get_settings_currency_key()
    unit_price = await _get_position_price(pos_id, cur)
    cost_cur = float(unit_price) * amount
    balance = await _get_user_balance(message.from_user.id, cur)
    sign = currencies[cur]["sign"]

    # "Детали счета"
    lines = [
        "🧾 <b>Детали счета</b>",
        "",
        f"✅ Заказ создан. [{amount} очков Steam]",
        "🔗 Отправьте ссылку на профиль Steam для продолжения.",
        f"💵 Сумма: {sign}{cost_cur:.2f}",
        f"💳 Баланс: {sign}{balance:.2f}",
    ]
    await message.answer("\n".join(lines), parse_mode=types.ParseMode.HTML, reply_markup=_cancel_kb())

    await state.update_data(pos_id=int(pos_id), amount=int(amount), cost_cur=float(cost_cur), balance=float(balance), cur=cur)
    await PointsBuy.waiting_link.set()


# ===== callback `points:start:<pos_id>` =====
@dp.callback_query_handler(lambda c: c.data and c.data.startswith("points:start:"), state=None)
async def cb_points_start(call: types.CallbackQuery, state: FSMContext):
    try:
        pos_id = int((call.data or "").split(":")[-1])
    except Exception:
        pos_id = DEFAULT_POS_ID

    await state.finish()
    await state.update_data(pos_id=int(pos_id))
    await call.message.answer("Введите количество очков Steam (например: 1000).", reply_markup=_cancel_kb())
    await call.answer()
    await PointsBuy.waiting_amount.set()


@dp.message_handler(state=PointsBuy.waiting_amount, content_types=types.ContentTypes.TEXT)
async def take_amount_then_details(message: types.Message, state: FSMContext):
    data = await state.get_data()
    pos_id = int(data.get("pos_id") or DEFAULT_POS_ID)

    try:
        amount = int((message.text or "").replace(" ", ""))
    except Exception:
        await message.answer("Количество должно быть целым числом. Пример: 1000", reply_markup=_cancel_kb())
        return
    if amount <= 0 or amount % POINTS_STEP != 0:
        await message.answer(f"Количество должно быть положительным и кратным {POINTS_STEP}.", reply_markup=_cancel_kb())
        return

    cur = await _get_settings_currency_key()
    unit_price = await _get_position_price(pos_id, cur)
    cost_cur = float(unit_price) * amount
    balance = await _get_user_balance(message.from_user.id, cur)
    sign = currencies[cur]["sign"]

    lines = [
        "🧾 <b>Детали счета</b>",
        "",
        f"✅ Заказ создан. [{amount} очков Steam]",
        "🔗 Отправьте ссылку на профиль Steam для продолжения.",
        f"💵 Сумма: {sign}{cost_cur:.2f}",
        f"💳 Баланс: {sign}{balance:.2f}",
    ]
    await message.answer("\n".join(lines), parse_mode=types.ParseMode.HTML, reply_markup=_cancel_kb())

    await state.update_data(pos_id=int(pos_id), amount=int(amount), cost_cur=float(cost_cur), balance=float(balance), cur=cur)
    await PointsBuy.waiting_link.set()


# ==================== получение ссылки ====================
@dp.message_handler(state=PointsBuy.waiting_link, content_types=types.ContentTypes.TEXT)
async def points_take_link(message: types.Message, state: FSMContext):
    steam_link = (message.text or "").strip()
    if not (steam_link.startswith("http://") or steam_link.startswith("https://")):
        await message.answer("Пришлите корректную ссылку на профиль Steam.", reply_markup=_cancel_kb())
        return

    data = await state.get_data()
    amount = int(data.get("amount") or 0)
    cost_cur = float(data.get("cost_cur") or 0.0)
    balance = float(data.get("balance") or 0.0)
    cur = data.get("cur") or await _get_settings_currency_key()
    sign = currencies[cur]["sign"]

    before_points = await _fetch_awards_points(steam_link)

    # 1) Проверяем и списываем RUB атомарно (до запроса к внешнему API)
    amount_rub = await _cost_to_rub(cur, cost_cur)
    ok_deduct = await _try_deduct_rub(message.from_user.id, float(amount_rub))
    if not ok_deduct:
        await message.answer("❌ Недостаточно средств на счёте. Пополните баланс и повторите покупку.", reply_markup=_cancel_kb())
        await state.finish()
        return

    # 2) Создаём заказ на стороне сервиса
    # 2) Создаём заказ на стороне сервиса (под защитой)
    try:
        ok, payload = await _create_points_order(
            user_id=message.from_user.id,
            steam_link=steam_link,
            amount=amount,
            unit_price=(_read_points_unit_price_override() or (cost_cur / amount if amount else 1.0)),
        )
    except Exception as _e:
        await _refund_rub(message.from_user.id, float(amount_rub))
        log.exception("Create order crashed: %r", _e)
        await message.answer("❌ Не удалось создать заказ (связь с провайдером). Попробуйте позже.", reply_markup=_cancel_kb())
        await state.finish()
        return

    if not ok:
        await _refund_rub(message.from_user.id, float(amount_rub))
        await message.answer("❌ Не удалось создать заказ. Попробуйте позже или обратитесь в поддержку.", reply_markup=_cancel_kb())
        await state.finish()
        return

    # 3) Успех — продолжаем формировать ответ
    new_balance = max(0.0, balance - cost_cur)
    lines = [
        "📦 <b>Статус заказа</b>",
        "",
        "✅ Заказ получен!",
        f"🎯 Начисленные очки: {amount}",
    ]
    if isinstance(before_points, int):
        lines.append(f"🧮 Очки Steam до заказа: {before_points:,}".replace(",", " "))
    lines.append(f"💳 Списано: {sign}{cost_cur:.2f}")
    lines.append(f"🏦 Остаток на счету: {sign}{new_balance:.2f}")
    lines.append("")
    lines.append("🔗 Открыть награды")
    lines.append(_awards_url(steam_link))

    await message.answer("\n".join(lines), disable_web_page_preview=True, parse_mode=types.ParseMode.HTML)
    # Уведомление админам о покупке
    try:
        data_block = payload.get('data', {}) if isinstance(payload, dict) else {}
        receipt = data_block.get('pay_order_no') or data_block.get('order_no') or data_block.get('buy_offer_id') or '-'
        msg_admin = (
            '💰 Новая покупка!\n'
            f'👤 Пользователь: {message.from_user.full_name} (@{message.from_user.username or "-"}, ID: {message.from_user.id})\n'
            f'💵 Сумма: {sign}{cost_cur:.2f}\n'
            f'🧾 Чек: {receipt}\n'
            f'⚙️ Кол-во очков: {amount}'
        )
        await send_admins(msg_admin, False)
    except Exception:
        pass
    await state.finish()


# =============== Cancel -> карточка товара ===============
@dp.callback_query_handler(lambda c: c.data == "points:cancel", state="*")
async def cancel_to_product(call: types.CallbackQuery, state: FSMContext):
    await state.finish()
    try:
        await call.message.delete()
    except Exception:
        pass
    await _send_product_card(call.message.chat.id, call.from_user.id, DEFAULT_POS_ID)
    await call.answer()


async def _cost_to_rub(cur: str, amount: float) -> float:
    """Преобразует сумму из валюты cur в RUB."""
    if cur.lower() == "rub":
        return float(amount)
    try:
        return float(await get_exchange(amount, cur.upper(), "RUB"))
    except Exception:
        return float(amount)



async def _try_deduct_rub(user_id: int, amount_rub: float) -> bool:
    """Атомарное списание в RUB через условный UPDATE; True если успешно."""
    try:
        await db.con.execute(
            """UPDATE users
                   SET balance_rub = balance_rub - ?
                 WHERE id = ? AND balance_rub >= ?""",
            (float(amount_rub), int(user_id), float(amount_rub))
        )
        await db.con.commit()
        row = await db.con.execute("SELECT changes() AS ch")
        res = await row.fetchone()
        ch = res.get("ch") if isinstance(res, dict) else (res[0] if res else 0)
        return bool(ch)
    except Exception:
        return False

async def _refund_rub(user_id: int, amount_rub: float) -> None:
    try:
        await db.con.execute(
            "UPDATE users SET balance_rub = balance_rub + ? WHERE id = ?",
            (float(amount_rub), int(user_id))
        )
        await db.con.commit()
    except Exception:
        pass

