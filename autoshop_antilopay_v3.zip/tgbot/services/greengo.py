import aiohttp

class GreenGo:
    def __init__(self, token: str):
        self.token = token
        self.headers = {
            "Api-Secret": self.token,
            "Content-Type": "application/json"
        }
        self.timeout = aiohttp.ClientTimeout(total=360)
        self.base_url = "https://api.greengo.cc/api/v2"

    async def create_order(self, amount: int | float):
        params = {
            "payment_method": "card",
            "from_amount": amount,
        }
        async with aiohttp.ClientSession(headers=self.headers, timeout=self.timeout) as session:
            response = await session.post(f"{self.base_url}/order/create", json=params)
            if response.status == 200:
                response_json = await response.json(content_type="text/html")
                await session.close()
                return response_json
            else:
                await session.close()
                return f"{response.status}: {await response.json()}"

    async def check_payment(self, order_id: str):
        params = {
            "order_id": [order_id]
        }
        async with aiohttp.ClientSession(headers=self.headers, timeout=self.timeout) as session:
            response = await session.post(f"{self.base_url}/order/check", json=params)
            if response.status == 200:
                response_json = await response.json()
                await session.close()
                if response_json.get("data"):
                    if response_json.get('data').get("orders"):
                        if len(response_json['data']['orders']) > 0:
                            order = response_json['data']['orders'][0]
                            if order['order_status'] in ["completed", "payed"]:
                                return True
                            else:
                                return False
                        else:
                            return False
                    else:
                        return False
                else:
                    return False
            else:
                await session.close()
                return f"{response.status}: {await response.json()}"