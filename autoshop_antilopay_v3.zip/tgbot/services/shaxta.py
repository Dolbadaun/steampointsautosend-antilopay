import aiohttp


class Shaxta:
    def __init__(self, api_token: str):
        self.token = api_token
        self.base_url = "https://btcapiplus.space/api/"
        self.timeout = aiohttp.ClientTimeout(total=360)

    async def create_order(self, amount: int):
        async with aiohttp.ClientSession(timeout=self.timeout) as session:
            params = {
                "apiKey": self.token,
                "amount": amount
            }

            response = await session.post(url=f"{self.base_url}?new-order", data=params)
            response_json = await response.json(content_type='text/html')
            await session.close()

        return response_json

    async def check_order(self, order_id: int):
        async with aiohttp.ClientSession(timeout=self.timeout) as session:
            params = {
                "apiKey": self.token,
                "orderId": order_id
            }

            response = await session.post(url=f"{self.base_url}?check-order", data=params)
            response_json = await response.json(content_type='text/html')
            await session.close()

        if response_json['data']['status'] == "confirmed":
            return True
        else:
            return False

