from decimal import Decimal, ROUND_HALF_UP
from urllib.parse import urlencode
import requests

SCALE = Decimal("0.001")
def _q(x) -> Decimal:
    return (Decimal(str(x))).quantize(SCALE, rounding=ROUND_HALF_UP)

class YooMoney:
    """
    Обёртка под ЛИЧНЫЙ кошелёк YooMoney (не YooKassa).
    Совместима по интерфейсу со старым классом:
      - create_yoomoney_link(amount, comment) -> str
      - check_yoomoney_payment(comment) -> bool
      - get_balance() -> Decimal
    Вызовы синхронные (как в оригинальном SDK), чтобы не ломать текущие хендлеры.
    """
    def __init__(self, token: str, number: str):
        self.token = token.strip()
        self.number = number.strip()
        self.base = "https://yoomoney.ru/api"
        self.headers = {"Authorization": f"Bearer {self.token}"}
        self.timeout = 20

    def create_yoomoney_link(self, amount, comment):
        params = {
            "receiver": self.number,
            "quickpay-form": "shop",
            "paymentType": "",  # плательщик выберет способ
            "sum": f"{_q(amount):.3f}",
            "label": str(comment),
            "comment": f"Order {comment}",
            "successURL": "",
        }
        return "https://yoomoney.ru/quickpay/confirm.xml?" + urlencode(params, doseq=True, safe=":/")

    def _post(self, path: str, data=None):
        r = requests.post(self.base + path, data=data or {}, headers=self.headers, timeout=self.timeout)
        try:
            return r.json()
        except Exception:
            return {"status": r.status_code, "text": r.text}

    def check_yoomoney_payment(self, comment):
        js = self._post("/operation-history", {"label": str(comment), "records": "50"})
        ops = js.get("operations") or []
        for op in ops:
            # direction может отсутствовать — считаем это входящей
            if op.get("direction") not in (None, "in"):
                continue
            if str(op.get("label")) == str(comment):
                return True
        return False

    def get_balance(self):
        js = self._post("/account-info")
        bal = js.get("balance") or js.get("account_balance") or 0
        return _q(bal)
