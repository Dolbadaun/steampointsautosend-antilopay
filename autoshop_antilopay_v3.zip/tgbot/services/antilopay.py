# - *- coding: utf- 8 - *-
import aiohttp
import hashlib
import uuid
import time
from loguru import logger as log


class Antilopay:
    """
    Интеграция с платёжной системой Antilopay
    Документация: https://docs.antilopay.com/
    """
    
    def __init__(self, project_id: str, secret_key: str):
        self.project_id = project_id.strip() if project_id else ""
        self.secret_key = secret_key.strip() if secret_key else ""
        self.base_url = "https://api.antilopay.com/api/v1"
        self.timeout = aiohttp.ClientTimeout(total=60)
        
    def _generate_sign(self, data: dict) -> str:
        """Генерация подписи для запроса"""
        # Сортируем ключи и формируем строку для подписи
        sorted_keys = sorted(data.keys())
        sign_string = ''.join([str(data[key]) for key in sorted_keys if data[key] is not None])
        sign_string += self.secret_key
        return hashlib.sha256(sign_string.encode()).hexdigest()
    
    def _generate_order_id(self) -> str:
        """Генерация уникального ID заказа"""
        return f"{int(time.time() * 1000)}_{uuid.uuid4().hex[:8]}"
    
    async def create_payment(self, amount: float, order_id: str = None, description: str = None) -> dict:
        """
        Создание платежа
        
        Args:
            amount: Сумма платежа в рублях
            order_id: Уникальный ID заказа (опционально)
            description: Описание платежа (опционально)
            
        Returns:
            dict с результатом: {'success': bool, 'payment_id': str, 'pay_url': str} или {'success': False, 'error': str}
        """
        if not order_id:
            order_id = self._generate_order_id()
            
        if not description:
            description = f"Пополнение баланса #{order_id}"
        
        data = {
            "project_identificator": self.project_id,
            "amount": float(amount),
            "order_id": order_id,
            "currency": "RUB",
            "description": description,
        }
        
        data["sign"] = self._generate_sign(data)
        
        try:
            async with aiohttp.ClientSession(timeout=self.timeout) as session:
                async with session.post(
                    f"{self.base_url}/payment/create",
                    json=data,
                    headers={"Content-Type": "application/json"}
                ) as resp:
                    result = await resp.json()
                    
                    if resp.status == 200 and result.get("success"):
                        return {
                            "success": True,
                            "payment_id": result.get("payment_id") or order_id,
                            "pay_url": result.get("pay_url") or result.get("url"),
                            "order_id": order_id
                        }
                    else:
                        error_msg = result.get("message") or result.get("error") or "Unknown error"
                        log.error(f"Antilopay create_payment error: {error_msg}")
                        return {"success": False, "error": error_msg}
                        
        except Exception as e:
            log.error(f"Antilopay create_payment exception: {e}")
            return {"success": False, "error": str(e)}
    
    async def check_payment(self, order_id: str) -> bool:
        """
        Проверка статуса платежа
        
        Args:
            order_id: ID заказа
            
        Returns:
            True если платёж оплачен, False в противном случае
        """
        data = {
            "project_identificator": self.project_id,
            "order_id": order_id,
        }
        
        data["sign"] = self._generate_sign(data)
        
        try:
            async with aiohttp.ClientSession(timeout=self.timeout) as session:
                async with session.post(
                    f"{self.base_url}/payment/status",
                    json=data,
                    headers={"Content-Type": "application/json"}
                ) as resp:
                    result = await resp.json()
                    
                    if resp.status == 200:
                        status = result.get("status", "").lower()
                        # Статусы: pending, processing, success, failed, expired
                        return status in ["success", "paid", "completed"]
                    return False
                    
        except Exception as e:
            log.error(f"Antilopay check_payment exception: {e}")
            return False
    
    def get_link(self, amount: float, order_id: str = None) -> tuple:
        """
        Синхронный метод для получения ссылки на оплату (для совместимости)
        Возвращает кортеж (order_id, pay_url_coroutine)
        """
        if not order_id:
            order_id = self._generate_order_id()
        return order_id


# Комиссия Antilopay (5%)
ANTILOPAY_COMMISSION = 0.05
